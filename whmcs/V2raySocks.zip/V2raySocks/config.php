<?php
define('Default_Lang', 'chinese');