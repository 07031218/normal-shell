#!/bin/bash
cd /home/deck/xunyou

DEFAULT_IF=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}')
[ -z "$DEFAULT_IF" ] && DEFAULT_IF=$(ls /sys/class/net | grep -v lo | head -n 1)

# 放行局域网 APP 发现协议与加速数据通道
iptables -I INPUT -p udp --dport 9999 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 9080 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 9443 -j ACCEPT 2>/dev/null || true

# 核心修补与伪装注入
find ./scripts -type f -name "*.sh" -exec sed -i '1s|/bin/sh|/bin/bash|' {} +
sed -i -E "s/LAN_IF_NAME=\".*\"/LAN_IF_NAME=\"$DEFAULT_IF\"/g" scripts/xunyou_daemon.sh
sed -i -E "s/SYSTEM_TYPE=\".*\"/SYSTEM_TYPE=\"steam\"/g" scripts/xunyou_daemon.sh
sed -i -E "s/VENDOR=\".*\"/VENDOR=\"steam\"/g" scripts/xunyou_daemon.sh
sed -i -E "s/MODEL=\".*\"/MODEL=\"steam_deck\"/g" scripts/xunyou_daemon.sh
sed -i 's|FILEWALL_SHELL="${PLUGIN_DIR}/firewall.sh"|FILEWALL_SHELL="${PLUGIN_DIR}/scripts/xunyou_firewall.sh"|g' scripts/xunyou_daemon.sh

# 封印官方自动更新
sed -i 's/exec_upgrade/true/g' scripts/xunyou_daemon.sh

echo "🚀 原生运行环境及底层网络库就绪，启动守护引擎..."
bash scripts/xunyou_daemon.sh restart
