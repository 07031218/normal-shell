#!/bin/sh

[ -f /etc/profile ] && . /etc/profile >/dev/null

ACTION=$1

SYSTEM_TYPE=""
PLUGIN_DIR=""
IF_NAME=""
IF_MAC=""
MODEL=""

WORK_DIR="/tmp/xunyou"

POST_PROC="xunyou_post"

get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

env_init()
{
    local hostname=`uname -n`
    
    SYSTEM_TYPE="steam"
    PLUGIN_DIR="/home/deck/xunyou"
    IF_NAME="wlan0"
    MODEL="steam_deck"

    IF_MAC=`ip address show ${IF_NAME} | grep link/ether | awk -F ' ' '{print $2}'`
    if [ -z "${IF_MAC}" ]; then
        echo "Can't find the lan mac!"
        return 1
    fi

    return 0
}

stop_plugin()
{
    systemctl disable xyplugin > /dev/null 2>&1
    #sh ${PLUGIN_DIR}/xunyou_daemon.sh stop
    
    if [ "${ACTION}" == "upgrade" -o "${ACTION}" == "app_uninstall" ]; then
        sh ${PLUGIN_DIR}/xunyou_daemon.sh stop
    else
        systemctl stop xyplugin > /dev/null 2>&1
    fi
}

delete_plugin()
{
    rm -rf ${WORK_DIR}
    rm -rf ${PLUGIN_DIR}
}

delete_ca()
{
    if [ -d "/home/deck/.pki/nssdb" ]; then
        certutil -D -d sql:/home/deck/.pki/nssdb -n "XunYouRootCA" > /dev/null 2>&1
    fi
    if [ -d "/home/deck/.var/app/com.valvesoftware.Steam/.pki/nssdb" ]; then
        certutil -D -d sql:/home/deck/.var/app/com.valvesoftware.Steam/.pki/nssdb -n "XunYouRootCA" > /dev/null 2>&1
    fi
    #trust extract-compat
    #update-ca-trust
}

env_init
if [ $? -ne 0 ]; then
    exit 1
fi

stop_plugin

delete_ca

delete_plugin
