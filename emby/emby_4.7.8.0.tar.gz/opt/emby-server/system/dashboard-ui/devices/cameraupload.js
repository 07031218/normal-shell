define(["exports", "./../modules/viewmanager/baseview.js", "./../modules/emby-elements/emby-input/emby-input.js", "./../modules/emby-elements/emby-button/emby-button.js", "./../modules/emby-elements/emby-checkbox/emby-checkbox.js", "./../modules/formhelper.js", "./../modules/loading/loading.js", "./../modules/common/globalize.js"], function (_exports, _baseview, _embyInput, _embyButton, _embyCheckbox, _formhelper, _loading, _globalize) {
    function loadData(page) {
        _loading.default.show(), ApiClient.getNamedConfiguration("devices").then(function (config) {
            ! function (page, config) {
                page.querySelector("#txtUploadPath").value = config.CameraUploadPath || "", page.querySelector("#chkSubfolder").checked = config.EnableCameraUploadSubfolders
            }(page, config), _loading.default.hide()
        })
    }

    function onSubmit(e) {
        return function (page) {
            ApiClient.getNamedConfiguration("devices").then(function (config) {
                config.CameraUploadPath = page.querySelector("#txtUploadPath").value, config.EnableCameraUploadSubfolders = page.querySelector("#chkSubfolder").checked, ApiClient.updateNamedConfiguration("devices", config).then(_formhelper.default.handleConfigurationSavedResponse)
            })
        }(this.closest(".page")), e.stopPropagation(), e.preventDefault(), !1
    }

    function View(view, params) {
        _baseview.default.apply(this, arguments), view.querySelector("#btnSelectUploadPath").addEventListener("click", function () {
            require(["directorybrowser"], function (directoryBrowser) {
                var picker = new directoryBrowser;
                picker.show({
                    callback: function (path) {
                        path && (view.querySelector("#txtUploadPath").value = path), picker.close()
                    },
                    validateWriteable: !0,
                    header: _globalize.default.translate("HeaderSelectUploadPath")
                })
            })
        }), view.querySelector(".devicesUploadForm").addEventListener("submit", onSubmit), view.querySelector(".premiereInfo").innerHTML = _globalize.default.translate("", '<a href="https://emby.media/premiere" data-preset="premiereinfo" is="emby-linkbutton" type="button" class="button-link">', "</a>")
    }
    Object.defineProperty(_exports, "__esModule", {
        value: !0
    }), _exports.default = void 0, Object.assign(View.prototype, _baseview.default.prototype), View.prototype.onResume = function (options) {
        _baseview.default.prototype.onResume.apply(this, arguments), loadData(this.view)
    }, _exports.default = View
});