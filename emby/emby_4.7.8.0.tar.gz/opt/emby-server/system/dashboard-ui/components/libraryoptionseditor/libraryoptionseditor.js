﻿define(["globalize", "dom", "require", "itemHelper", "apphost", "emby-checkbox", "emby-select", "emby-input"], function (globalize, dom, require, itemHelper, appHost) {
    "use strict";

    function populateLanguagesIntoSelect(select, languages) {
        var html = "";
        html += "<option value=''></option>";
        for (var i = 0, length = languages.length; i < length; i++) {
            var culture = languages[i];
            html += "<option value='" + culture.TwoLetterISOLanguageName + "'>" + culture.DisplayName + "</option>"
        }
        select.innerHTML = html
    }

    function populateLanguagesIntoList(apiClient, element, languages) {
        for (var html = "", i = 0, length = languages.length; i < length; i++) {
            var culture = languages[i];
            html += '<label><input type="checkbox" is="emby-checkbox" class="chkLanguage" data-lang="' + culture.TwoLetterISOLanguageName + '" data-altlang="' + culture.ThreeLetterISOLanguageName + '" /><span>' + culture.DisplayName + "</span></label>"
        }
        element.innerHTML = html
    }

    function populateMaxDownloadAge(select) {
        var html = "",
            html = (html += "<option value='0'>" + globalize.translate("NoAgeLimit") + "</option>") + [14, 30, 60, 90, 120, 180].map(function (val) {
                return "<option value='" + val + "'>" + globalize.translate("NDays", val) + "</option>"
            }).join("");
        select.innerHTML = html
    }

    function renderMetadataReaders(page, plugins, libraryOptions) {
        var html = "",
            page = page.querySelector(".metadataReaders");
        if (plugins.length < 1) return page.innerHTML = "", void page.classList.add("hide");
        html = html + ('<h3 class="checkboxListLabel">' + globalize.translate("HeaderMetadataReaders")) + '</h3><div class="checkboxList">';
        for (var i = 0, length = plugins.length; i < length; i++) {
            var plugin = plugins[i],
                features = plugin.Features || [];
            html += '<div class="listItem listItem-border localReaderOption sortableOption" data-pluginname="' + plugin.Name + '">';
            var checkedHtml = !libraryOptions.DisabledLocalMetadataReaders || -1 === libraryOptions.DisabledLocalMetadataReaders.indexOf(plugin.Name) ? ' checked="checked"' : "",
                html = (html = (html = (html += '<label class="listItemCheckboxContainer"><input type="checkbox" is="emby-checkbox" class="chkMetadataReader" data-features="' + features.join(",") + '" data-pluginname="' + plugin.Name + '" ' + checkedHtml + "><span>&nbsp;</span></label>") + '<div class="listItemBody">' + '<div class="listItemBodyText">') + plugin.Name) + "</div>" + "</div>";
            0 < i ? html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonUp") + '" aria-label="' + globalize.translate("ButtonUp") + '" class="btnSortableMoveUp btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_up</i></button>' : 1 < plugins.length && (html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonDown") + '" aria-label="' + globalize.translate("ButtonDown") + '" class="btnSortableMoveDown btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_down</i></button>'), html += "</div>"
        }
        html = (html += "</div>") + '<div class="fieldDescription">' + globalize.translate("LabelMetadataReadersHelp") + "</div>", page.classList.remove("hide"), page.innerHTML = html
    }

    function getTypeOptions(allOptions, type) {
        for (var allTypeOptions = allOptions.TypeOptions || [], i = 0, length = allTypeOptions.length; i < length; i++) {
            var typeOptions = allTypeOptions[i];
            if (typeOptions.Type === type) return typeOptions
        }
        return null
    }

    function renderMetadataFetchers(page, availableOptions, libraryOptions) {
        for (var html = "", elem = page.querySelector(".metadataFetchers"), i = 0, length = availableOptions.TypeOptions.length; i < length; i++) {
            var availableTypeOptions = availableOptions.TypeOptions[i];
            html += function (availableTypeOptions, libraryOptionsForType) {
                var plugins, html = "";
                if ((plugins = getOrderedPlugins(availableTypeOptions.MetadataFetchers || [], libraryOptionsForType.MetadataFetcherOrder || [])).length) {
                    html = (html += '<div class="metadataFetcher" style="margin-bottom:2em;" data-type="' + availableTypeOptions.Type + '">') + ('<h3 class="checkboxListLabel">' + globalize.translate("HeaderTypeMetadataDownloaders", itemHelper.getItemTypeName(availableTypeOptions.Type)) + "</h3>") + '<div class="checkboxList">';
                    for (var i = 0, length = plugins.length; i < length; i++) {
                        var plugin = plugins[i],
                            features = plugin.Features || [];
                        html += '<div class="listItem listItem-border metadataFetcherItem sortableOption" data-pluginname="' + plugin.Name + '">';
                        var checkedHtml = (libraryOptionsForType.MetadataFetchers ? -1 !== libraryOptionsForType.MetadataFetchers.indexOf(plugin.Name) : plugin.DefaultEnabled) ? ' checked="checked"' : "";
                        html = (html = (html += '<label class="listItemCheckboxContainer"><input type="checkbox" is="emby-checkbox" class="chkMetadataFetcher" data-features="' + features.join(",") + '" data-pluginname="' + plugin.Name + '" ' + checkedHtml + "><span>&nbsp;</span></label>") + '<div class="listItemBody">' + '<div class="listItemBodyText">') + plugin.Name + "</div>", "thetvdb" === (plugin.Name || "").toLowerCase() && (features = "元数据由 {0}TheTVDB{1} 提供。请考虑通过补齐缺失信息或购买订阅服务来支持它。", html = (html += '<div class="listItemBodyText listItemBodyText-secondary">') + (features = appHost.supports("externallinks") && appHost.supports("targetblank") ? features.replace("{0}", '<a is="emby-linkbutton" class="button-link" href="https://u10505776.ct.sendgrid.net/ls/click?upn=xMYYCP13hVd-2BZPpbVcMPHeLXfv-2BPRdIsKm2qSeirIHi7kH9am8IxD-2BavFbeqGqIXhYSX_3vJGkDxT-2BkunZNiBhP0A-2FgnzP8fpop8DS6eHDvUovCjNP0soWQW676fXXT2AIkyRKGna8SCDrkQjnhaj530jQSTa87HTuTDwvGiBqeSwPxTSgVxlxCgw4O-2BSuP8cT8LWN-2BvSLziJev27SJk22WNo8EAmmMxf9PnByhpFrDxhEhHfYN-2BUTgSydVQKwe4mFY53vPm-2Fus5xrLlvgo6e4STB4g-3D-3D" target="_blank">').replace("{1}", "</a>") : features.replace("{0}", "").replace("{1}", "")) + "</div>"), html += "</div>", 0 < i ? html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonUp") + '" aria-label="' + globalize.translate("ButtonUp") + '" class="btnSortableMoveUp btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_up</i></button>' : 1 < plugins.length && (html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonDown") + '" aria-label="' + globalize.translate("ButtonDown") + '" class="btnSortableMoveDown btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_down</i></button>'), html += "</div>"
                    }
                    html = (html += "</div>") + ('<div class="fieldDescription">' + globalize.translate("LabelMetadataDownloadersHelp") + "</div>") + "</div>"
                }
                return html
            }(availableTypeOptions, getTypeOptions(libraryOptions, availableTypeOptions.Type) || {})
        }(elem.innerHTML = html) ? (elem.classList.remove("hide"), page.querySelector(".fldAutoRefreshInterval").classList.remove("hide"), page.querySelector(".fldMetadataLanguage").classList.remove("hide"), page.querySelector(".fldMetadataCountry").classList.remove("hide")) : (elem.classList.add("hide"), page.querySelector(".fldAutoRefreshInterval").classList.add("hide"), page.querySelector(".fldMetadataLanguage").classList.add("hide"), page.querySelector(".fldMetadataCountry").classList.add("hide")), html ? page.querySelector(".fldImageLanguage").classList.remove("hide") : page.querySelector(".fldImageLanguage").classList.add("hide")
    }

    function renderLyricsFetchers(page, availableOptions, libraryOptions) {
        var plugins, html = "",
            page = page.querySelector(".lyricsFetchers");
        if ((plugins = getOrderedPlugins(availableOptions.LyricsFetchers || [], libraryOptions.LyricsFetcherOrder || [])).length) {
            html = html + ('<h3 class="checkboxListLabel">' + globalize.translate("HeaderSubtitleDownloaders") + "</h3>") + '<div class="checkboxList">';
            for (var i = 0, length = plugins.length; i < length; i++) {
                var plugin = plugins[i],
                    features = plugin.Features || [],
                    isChecked = (html += '<div class="listItem listItem-border subtitleLyricsItem sortableOption" data-pluginname="' + plugin.Name + '">', libraryOptions.DisabledLyricsFetchers ? -1 === libraryOptions.DisabledLyricsFetchers.indexOf(plugin.Name) : plugin.DefaultEnabled),
                    html = (html = (html += '<label class="listItemCheckboxContainer"><input type="checkbox" is="emby-checkbox" class="chkLyricsFetcher" data-pluginname="' + plugin.Name + '" ' + (isChecked ? ' checked="checked"' : "") + "><span>&nbsp;</span></label>") + '<div class="listItemBody">' + '<div class="listItemBodyText">') + plugin.Name + "</div>";
                features.includes("RequiredSetup") && (html = (html += '<div class="listItemBodyText listItemBodyText-secondary">') + globalize.translate("ProviderNeedsSetup", plugin.Name) + "</div>"), html += "</div>", 0 < i ? html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonUp") + '" aria-label="' + globalize.translate("ButtonUp") + '" class="btnSortableMoveUp btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_up</i></button>' : 1 < plugins.length && (html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonDown") + '" aria-label="' + globalize.translate("ButtonDown") + '" class="btnSortableMoveDown btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_down</i></button>'), html += "</div>"
            }
            html = (html += "</div>") + ('<div class="fieldDescription">' + globalize.translate("SubtitleDownloadersHelp") + "</div>"), page.innerHTML = html
        }
    }

    function renderSubtitleFetchers(page, availableOptions, libraryOptions) {
        var plugins, html = "",
            page = page.querySelector(".subtitleFetchers");
        if ((plugins = getOrderedPlugins(availableOptions.SubtitleFetchers || [], libraryOptions.SubtitleFetcherOrder || [])).length) {
            html = html + ('<h3 class="checkboxListLabel">' + globalize.translate("HeaderSubtitleDownloaders") + "</h3>") + '<div class="checkboxList">';
            for (var i = 0, length = plugins.length; i < length; i++) {
                var plugin = plugins[i],
                    features = plugin.Features || [],
                    isChecked = (html += '<div class="listItem listItem-border subtitleFetcherItem sortableOption" data-pluginname="' + plugin.Name + '">', libraryOptions.DisabledSubtitleFetchers ? -1 === libraryOptions.DisabledSubtitleFetchers.indexOf(plugin.Name) : plugin.DefaultEnabled),
                    html = (html = (html += '<label class="listItemCheckboxContainer"><input type="checkbox" is="emby-checkbox" class="chkSubtitleFetcher" data-pluginname="' + plugin.Name + '" ' + (isChecked ? ' checked="checked"' : "") + "><span>&nbsp;</span></label>") + '<div class="listItemBody">' + '<div class="listItemBodyText">') + plugin.Name + "</div>";
                features.includes("RequiredSetup") && (html = (html += '<div class="listItemBodyText listItemBodyText-secondary">') + globalize.translate("ProviderNeedsSetup", plugin.Name) + "</div>"), html += "</div>", 0 < i ? html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonUp") + '" aria-label="' + globalize.translate("ButtonUp") + '" class="btnSortableMoveUp btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_up</i></button>' : 1 < plugins.length && (html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonDown") + '" aria-label="' + globalize.translate("ButtonDown") + '" class="btnSortableMoveDown btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_down</i></button>'), html += "</div>"
            }
            html = (html += "</div>") + ('<div class="fieldDescription">' + globalize.translate("SubtitleDownloadersHelp") + "</div>"), page.innerHTML = html
        }
    }

    function renderImageFetchers(page, availableOptions, libraryOptions) {
        for (var html = "", elem = page.querySelector(".imageFetchers"), i = 0, length = availableOptions.TypeOptions.length; i < length; i++) {
            var availableTypeOptions = availableOptions.TypeOptions[i];
            html += function (availableTypeOptions, libraryOptionsForType) {
                var plugins, html = "";
                if ((plugins = getOrderedPlugins(availableTypeOptions.ImageFetchers || [], libraryOptionsForType.ImageFetcherOrder || [])).length) {
                    html = (html = html + ('<div class="imageFetcher" style="margin-bottom:2em;" data-type="' + availableTypeOptions.Type + '">') + '<div class="flex align-items-center" style="margin:1.5em 0 .5em;">') + ('<h3 class="checkboxListLabel" style="margin:0;">' + globalize.translate("HeaderTypeImageFetchers", itemHelper.getItemTypeName(availableTypeOptions.Type)) + "</h3>");
                    availableTypeOptions = availableTypeOptions.SupportedImageTypes || [];
                    (1 < availableTypeOptions.length || 1 === availableTypeOptions.length && "Primary" !== availableTypeOptions[0]) && (html += '<button is="emby-button" class="raised btnImageOptionsForType" type="button" style="margin-left:1.5em;font-size:90%;"><span>' + globalize.translate("HeaderFetcherSettings") + "</span></button>"), html = html + "</div>" + '<div class="checkboxList">';
                    for (var i = 0, length = plugins.length; i < length; i++) {
                        var plugin = plugins[i],
                            features = plugin.Features || [],
                            isChecked = (html += '<div class="listItem listItem-border imageFetcherItem sortableOption" data-pluginname="' + plugin.Name + '">', libraryOptionsForType.ImageFetchers ? -1 !== libraryOptionsForType.ImageFetchers.indexOf(plugin.Name) : plugin.DefaultEnabled),
                            html = (html = (html += '<label class="listItemCheckboxContainer"><input type="checkbox" is="emby-checkbox" class="chkImageFetcher" data-pluginname="' + plugin.Name + '" ' + (isChecked ? ' checked="checked"' : "") + "><span>&nbsp;</span></label>") + '<div class="listItemBody">' + '<div class="listItemBodyText">') + plugin.Name + "</div>";
                        features.includes("RequiredSetup") && (html = (html += '<div class="listItemBodyText listItemBodyText-secondary">') + globalize.translate("ProviderNeedsSetup", plugin.Name) + "</div>"), html += "</div>", 0 < i ? html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonUp") + '" aria-label="' + globalize.translate("ButtonUp") + '" class="btnSortableMoveUp btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_up</i></button>' : 1 < plugins.length && (html += '<button type="button" is="paper-icon-button-light" title="' + globalize.translate("ButtonDown") + '" aria-label="' + globalize.translate("ButtonDown") + '" class="btnSortableMoveDown btnSortable" data-pluginindex="' + i + '"><i class="md-icon">keyboard_arrow_down</i></button>'), html += "</div>"
                    }
                    html = (html += "</div>") + ('<div class="fieldDescription">' + globalize.translate("LabelImageFetchersHelp") + "</div>") + "</div>"
                }
                return html
            }(availableTypeOptions, getTypeOptions(libraryOptions, availableTypeOptions.Type) || {})
        }(elem.innerHTML = html) ? (elem.classList.remove("hide"), page.querySelector(".chkDownloadImagesInAdvanceContainer").classList.remove("hide"), page.querySelector(".chkSaveLocalContainer").classList.remove("hide")) : (elem.classList.add("hide"), page.querySelector(".chkDownloadImagesInAdvanceContainer").classList.add("hide"), page.querySelector(".chkSaveLocalContainer").classList.add("hide"))
    }
    var currentLibraryOptions, currentAvailableOptions;

    function populateMetadataSettings(parent, contentType) {
        var isNewLibrary = parent.classList.contains("newlibrary");
        return ApiClient.getJSON(ApiClient.getUrl("Libraries/AvailableOptions", {
            LibraryContentType: contentType,
            IsNewLibrary: isNewLibrary
        })).then(function (availableOptions) {
            currentAvailableOptions = availableOptions, parent.availableOptions = availableOptions,
                function (page, metadataSavers) {
                    var html = "",
                        page = page.querySelector(".metadataSavers");
                    if (!metadataSavers.length) return page.innerHTML = "", page.classList.add("hide");
                    for (var html = html + ('<h3 class="checkboxListLabel">' + globalize.translate("HeaderMetadataSavers") + "</h3>") + '<div class="checkboxList">', i = 0, length = metadataSavers.length; i < length; i++) {
                        var plugin = metadataSavers[i];
                        html += '<label><input type="checkbox" data-defaultenabled="' + plugin.DefaultEnabled + '" is="emby-checkbox" class="chkMetadataSaver" data-pluginname="' + plugin.Name + '" ' + !1 + "><span>" + plugin.Name + "</span></label>"
                    }
                    html = (html += "</div>") + '<div class="fieldDescription" style="margin-top:.25em;">' + globalize.translate("LabelMetadataSaversHelp") + "</div>", page.innerHTML = html, page.classList.remove("hide")
                }(parent, availableOptions.MetadataSavers), renderMetadataReaders(parent, availableOptions.MetadataReaders, {}), renderMetadataFetchers(parent, availableOptions, {}), renderSubtitleFetchers(parent, availableOptions, {}), renderLyricsFetchers(parent, availableOptions, {}), renderImageFetchers(parent, availableOptions, {}), availableOptions.SubtitleFetchers.length ? parent.querySelector(".subtitleDownloadSettings").classList.remove("hide") : parent.querySelector(".subtitleDownloadSettings").classList.add("hide"), (availableOptions.LyricsFetchers || []).length ? parent.querySelector(".lyricsDownloadSettings").classList.remove("hide") : parent.querySelector(".lyricsDownloadSettings").classList.add("hide"), onMetadataFetchersOrReadersChange.call(parent.querySelector(".metadataFetchers"))
        }).catch(function () {
            return Promise.resolve()
        })
    }

    function adjustSortableListElement(elem) {
        var btnSortable = elem.querySelector(".btnSortable");
        elem.previousElementSibling ? (btnSortable.classList.add("btnSortableMoveUp"), btnSortable.classList.remove("btnSortableMoveDown"), btnSortable.querySelector("i").innerHTML = "keyboard_arrow_up") : (btnSortable.classList.remove("btnSortableMoveUp"), btnSortable.classList.add("btnSortableMoveDown"), btnSortable.querySelector("i").innerHTML = "keyboard_arrow_down")
    }

    function onImageFetchersContainerClick(e) {
        var btnImageOptionsForType = e.target.closest(".btnImageOptionsForType");
        btnImageOptionsForType ? function (type) {
            require(["imageoptionseditor"], function (ImageOptionsEditor) {
                var typeOptions = getTypeOptions(currentLibraryOptions, type),
                    availableOptions = (typeOptions || currentLibraryOptions.TypeOptions.push(typeOptions = {
                        Type: type
                    }), getTypeOptions(currentAvailableOptions || {}, type));
                (new ImageOptionsEditor).show(type, typeOptions, availableOptions)
            })
        }(btnImageOptionsForType.closest(".imageFetcher").getAttribute("data-type")) : onSortableContainerClick.call(this, e)
    }

    function onSortableContainerClick(e) {
        var li, list, e = e.target.closest(".btnSortable");
        e && (list = (li = e.closest(".sortableOption")).closest(".checkboxList"), e.classList.contains("btnSortableMoveDown") ? (e = li.nextElementSibling) && (li.parentNode.removeChild(li), e.parentNode.insertBefore(li, e.nextElementSibling)) : (e = li.previousElementSibling) && (li.parentNode.removeChild(li), e.parentNode.insertBefore(li, e)), Array.prototype.forEach.call(list.querySelectorAll(".sortableOption"), adjustSortableListElement))
    }

    function onMetadataFetchersOrReadersChange(e) {
        for (var parent = this.closest(".libraryOptions"), checkedFeatures = Array.prototype.map.call(parent.querySelectorAll(".chkMetadataFetcher:checked"), function (elem) {
                elem = elem.getAttribute("data-features");
                return elem ? elem.split(",") : []
            }), allFeatures = [], i = 0, length = checkedFeatures.length; i < length; i++) allFeatures = allFeatures.concat(checkedFeatures[i]);
        allFeatures.includes("Collections") ? parent.querySelector(".fldImportCollections").classList.remove("hide") : parent.querySelector(".fldImportCollections").classList.add("hide"), allFeatures.includes("Adult") ? parent.querySelector(".fldAdult").classList.remove("hide") : parent.querySelector(".fldAdult").classList.add("hide"), onImportCollectionsChange.call(parent.querySelector(".chkImportCollections"))
    }

    function onImportCollectionsChange(e) {
        for (var parent = this.closest(".libraryOptions"), fldMinCollectionSize = parent.querySelector(".fldMinCollectionSize"), metadataReaders = Array.prototype.map.call(parent.querySelectorAll(".chkMetadataReader:checked"), function (elem) {
                elem = elem.getAttribute("data-features");
                return elem ? elem.split(",") : []
            }), metadataReaderFeatures = [], i = 0, length = metadataReaders.length; i < length; i++) metadataReaderFeatures = metadataReaderFeatures.concat(metadataReaders[i]);
        metadataReaderFeatures.includes("Collections") || this.checked && parent.querySelector(".fldImportCollections:not(.hide)") ? fldMinCollectionSize.classList.remove("hide") : fldMinCollectionSize.classList.add("hide")
    }

    function onThumbnailScheduleChange(e) {
        var e = e.target.closest(".thumbnailSettingsSection"),
            fldThumbnailInterval = e.querySelector(".fldThumbnailInterval"),
            fldThumbnailInterval = (this.value ? fldThumbnailInterval.classList.remove("hide") : fldThumbnailInterval.classList.add("hide"), e.querySelector(".selectThumbnailInterval"));
        onThumbnailIntervalChange.call(fldThumbnailInterval, {
            target: fldThumbnailInterval
        })
    }

    function onThumbnailIntervalChange(e) {
        var e = e.target.closest(".thumbnailSettingsSection"),
            fldSaveThumbnailSetsLocally = e.querySelector(".fldSaveThumbnailSetsLocally"),
            e = e.querySelector(".selectThumbnailImages");
        "-1" !== this.value && e.value ? fldSaveThumbnailSetsLocally.classList.remove("hide") : fldSaveThumbnailSetsLocally.classList.add("hide")
    }

    function triggerElementEvents(parent) {
        var selectThumbnailImages = parent.querySelector(".selectThumbnailImages"),
            selectThumbnailImages = (onThumbnailScheduleChange.call(selectThumbnailImages, {
                target: selectThumbnailImages
            }), parent.querySelector(".selectThumbnailInterval")),
            selectThumbnailImages = (onThumbnailIntervalChange.call(selectThumbnailImages, {
                target: selectThumbnailImages
            }), parent.querySelector(".chkImportCollections"));
        onImportCollectionsChange.call(selectThumbnailImages, {
            target: selectThumbnailImages
        })
    }

    function setContentType(parent, contentType) {
        return "homevideos" === contentType ? parent.querySelector(".chkEnablePhotosContainer").classList.remove("hide") : parent.querySelector(".chkEnablePhotosContainer").classList.add("hide"), ApiClient.isMinServerVersion("4.7.0.19") ? parent.querySelector(".fldSubtitleDownloadMaxAge").classList.remove("hide") : parent.querySelector(".fldSubtitleDownloadMaxAge").classList.add("hide"), ApiClient.isMinServerVersion("4.7.0.21") ? parent.querySelector(".fldLyricsDownloadMaxAge").classList.remove("hide") : parent.querySelector(".fldLyricsDownloadMaxAge").classList.add("hide"), contentType && "music" !== contentType && "audiobooks" !== contentType || !ApiClient.isMinServerVersion("4.7.0.19") ? parent.querySelector(".fldImportPlaylists").classList.add("hide") : parent.querySelector(".fldImportPlaylists").classList.remove("hide"), "tvshows" !== contentType && "movies" !== contentType && "homevideos" !== contentType && "musicvideos" !== contentType && "mixed" !== contentType && contentType ? parent.querySelector(".thumbnailSettingsSection").classList.add("hide") : parent.querySelector(".thumbnailSettingsSection").classList.remove("hide"), "tvshows" !== contentType && contentType || !ApiClient.isMinServerVersion("4.7.2") ? parent.querySelector(".introDetectionSection").classList.add("hide") : parent.querySelector(".introDetectionSection").classList.remove("hide"), "tvshows" !== contentType && "movies" !== contentType && "homevideos" !== contentType && "musicvideos" !== contentType && "mixed" !== contentType && "audiobooks" !== contentType && contentType ? (parent.querySelector(".playbackSettings").classList.add("hide"), parent.querySelector("#txtMinResumePct").removeAttribute("required"), parent.querySelector("#txtMaxResumePct").removeAttribute("required"), parent.querySelector("#txtMinResumeDuration").removeAttribute("required")) : (parent.querySelector(".playbackSettings").classList.remove("hide"), parent.querySelector("#txtMinResumePct").setAttribute("required", "required"), parent.querySelector("#txtMaxResumePct").setAttribute("required", "required"), parent.querySelector("#txtMinResumeDuration").setAttribute("required", "required")), "music" === contentType || "audiobooks" === contentType ? parent.querySelector(".musicFolderStructureSection").classList.remove("hide") : parent.querySelector(".musicFolderStructureSection").classList.add("hide"), "tvshows" === contentType ? (parent.querySelector(".chkImportMissingEpisodesContainer").classList.remove("hide"), parent.querySelector(".chkAutomaticallyGroupSeriesContainer").classList.remove("hide"), parent.querySelector(".fldSeasonZeroDisplayName").classList.remove("hide"), parent.querySelector("#txtSeasonZeroName").setAttribute("required", "required")) : (parent.querySelector(".chkImportMissingEpisodesContainer").classList.add("hide"), parent.querySelector(".chkAutomaticallyGroupSeriesContainer").classList.add("hide"), parent.querySelector(".fldSeasonZeroDisplayName").classList.add("hide"), parent.querySelector("#txtSeasonZeroName").removeAttribute("required")), "games" === contentType || "books" === contentType || "boxsets" === contentType || "playlists" === contentType || "music" === contentType ? parent.querySelector(".chkEnableEmbeddedTitlesContainer").classList.add("hide") : parent.querySelector(".chkEnableEmbeddedTitlesContainer").classList.remove("hide"), ApiClient.getSystemInfo().then(function (info) {
            "Windows" === info.OperatingSystem ? parent.querySelector(".fldSaveMetadataHidden").classList.remove("hide") : parent.querySelector(".fldSaveMetadataHidden").classList.add("hide")
        }), parent.querySelector(".chkEnableAudioResume").checked = "audiobooks" === contentType, populateMetadataSettings(parent, contentType)
    }

    function getOrderedPlugins(plugins, configuredOrder) {
        return (plugins = plugins.slice(0)).sort(function (a, b) {
            return (a = configuredOrder.indexOf(a.Name)) < (b = configuredOrder.indexOf(b.Name)) ? -1 : b < a ? 1 : 0
        }), plugins
    }

    function setLibraryOptions(parent, options) {
        currentLibraryOptions = options, currentAvailableOptions = parent.availableOptions, parent.querySelector("#selectLanguage").value = options.PreferredMetadataLanguage || "", parent.querySelector("#selectImageLanguage").value = options.PreferredImageLanguage || "", parent.querySelector("#selectCountry").value = options.MetadataCountryCode || "", parent.querySelector("#selectAutoRefreshInterval").value = options.AutomaticRefreshIntervalDays || "0", parent.querySelector("#txtSeasonZeroName").value = options.SeasonZeroDisplayName || "Specials", parent.querySelector(".chkEnablePhotos").checked = options.EnablePhotos, parent.querySelector(".chkImportPlaylists").checked = !1 !== options.ImportPlaylists, parent.querySelector(".chkEnableRealtimeMonitor").checked = options.EnableRealtimeMonitor, parent.querySelector(".selectMusicFolderStructure").value = options.MusicFolderStructure || "", parent.querySelector(".selectMinCollectionSize").value = options.MinCollectionItems || 2, parent.querySelector(".chkImportCollections").checked = options.ImportCollections || !1, parent.querySelector(".chkAdult").checked = options.EnableAdultMetadata || !1, parent.querySelector(".selectThumbnailImages").value = options.EnableChapterImageExtraction && options.ExtractChapterImagesDuringLibraryScan ? "scanandtask" : options.EnableChapterImageExtraction ? "task" : "", parent.querySelector(".chkLocalThumbnailSets").checked = options.SaveLocalThumbnailSets, parent.querySelector(".selectThumbnailInterval").value = options.ThumbnailImagesIntervalSeconds || "10", parent.querySelector(".selectIntroDetection").value = options.EnableMarkerDetection && options.EnableMarkerDetectionDuringLibraryScan ? "scanandtask" : options.EnableMarkerDetection ? "task" : "", parent.querySelector("#chkDownloadImagesInAdvance").checked = options.DownloadImagesInAdvance, parent.querySelector("#chkSaveLocal").checked = options.SaveLocalMetadata, parent.querySelector("#chkImportMissingEpisodes").checked = options.ImportMissingEpisodes, parent.querySelector(".chkAutomaticallyGroupSeries").checked = options.EnableAutomaticSeriesGrouping, parent.querySelector("#chkEnableEmbeddedTitles").checked = options.EnableEmbeddedTitles, parent.querySelector("#chkSkipIfGraphicalSubsPresent").checked = options.SkipSubtitlesIfEmbeddedSubtitlesPresent, parent.querySelector("#chkSaveSubtitlesLocally").checked = options.SaveSubtitlesWithMedia, parent.querySelector("#chkSaveLyricsLocally").checked = options.SaveLyricsWithMedia, parent.querySelector(".selectSubtitleDownloadMaxAge").value = null == options.SubtitleDownloadMaxAgeDays ? 180 : options.SubtitleDownloadMaxAgeDays, parent.querySelector("#chkSkipIfAudioTrackPresent").checked = options.SkipSubtitlesIfAudioTrackMatches, parent.querySelector(".chkRequireHashMatch").checked = options.RequirePerfectSubtitleMatch, parent.querySelector(".chkForcedSubtitlesOnly").checked = options.ForcedSubtitlesOnly, parent.querySelector(".selectLyricsDownloadMaxAge").value = null == options.LyricsDownloadMaxAgeDays ? 180 : options.LyricsDownloadMaxAgeDays, parent.querySelector("#txtMinResumePct").value = null == options.MinResumePct ? "3" : options.MinResumePct, parent.querySelector("#txtMaxResumePct").value = null == options.MaxResumePct ? "90" : options.MaxResumePct, parent.querySelector("#txtMinResumeDuration").value = null == options.MinResumeDurationSeconds ? "120" : options.MinResumeDurationSeconds, parent.querySelector(".chkSaveMetadataHidden").checked = options.SaveMetadataHidden || !1, Array.prototype.forEach.call(parent.querySelectorAll(".chkMetadataSaver"), function (elem) {
            elem.checked = options.MetadataSavers ? -1 !== options.MetadataSavers.indexOf(elem.getAttribute("data-pluginname")) : "true" === elem.getAttribute("data-defaultenabled")
        }), Array.prototype.forEach.call(parent.querySelectorAll(".subtitleDownloadLanguages .chkLanguage"), function (elem) {
            elem.checked = !!options.SubtitleDownloadLanguages && (-1 !== options.SubtitleDownloadLanguages.indexOf(elem.getAttribute("data-lang")) || -1 !== options.SubtitleDownloadLanguages.indexOf(elem.getAttribute("data-altlang")))
        }), Array.prototype.forEach.call(parent.querySelectorAll(".lyricsDownloadLanguages .chkLanguage"), function (elem) {
            elem.checked = !!options.LyricsDownloadLanguages && (-1 !== options.LyricsDownloadLanguages.indexOf(elem.getAttribute("data-lang")) || -1 !== options.LyricsDownloadLanguages.indexOf(elem.getAttribute("data-altlang")))
        }), renderMetadataReaders(parent, getOrderedPlugins(parent.availableOptions.MetadataReaders || [], options.LocalMetadataReaderOrder || []), options), renderMetadataFetchers(parent, parent.availableOptions, options), renderImageFetchers(parent, parent.availableOptions, options), renderSubtitleFetchers(parent, parent.availableOptions, options), renderLyricsFetchers(parent, parent.availableOptions, options), triggerElementEvents(parent)
    }
    return {
        embed: function (parent, contentType, libraryOptions) {
            currentLibraryOptions = {
                TypeOptions: []
            };
            var isNewLibrary = (currentAvailableOptions = null) == libraryOptions;
            return isNewLibrary && parent.classList.add("newlibrary"), require(["text!./libraryoptionseditor.template.html"]).then(function (responses) {
                parent.innerHTML = globalize.translateDocument(responses[0]), responses = parent.querySelector("#selectAutoRefreshInterval"), html = "", html = (html += "<option value='0'>" + globalize.translate("Never") + "</option>") + [1, 2, 3, 5, 7, 10, 30, 60, 90].map(function (val) {
                    return "<option value='" + val + "'>" + globalize.translate("EveryNDays", val) + "</option>"
                }).join(""), responses.innerHTML = html, populateMaxDownloadAge(parent.querySelector(".selectSubtitleDownloadMaxAge")), populateMaxDownloadAge(parent.querySelector(".selectLyricsDownloadMaxAge"));
                var html, responses = [function (parent) {
                    return ApiClient.getCultures().then(function (languages) {
                        populateLanguagesIntoSelect(parent.querySelector("#selectLanguage"), languages), populateLanguagesIntoSelect(parent.querySelector("#selectImageLanguage"), languages), populateLanguagesIntoList(ApiClient, parent.querySelector(".subtitleDownloadLanguages"), languages), populateLanguagesIntoList(ApiClient, parent.querySelector(".lyricsDownloadLanguages"), languages)
                    })
                }(parent), function (select) {
                    return ApiClient.getCountries().then(function (allCountries) {
                        var html = "";
                        html += "<option value=''></option>";
                        for (var i = 0, length = allCountries.length; i < length; i++) {
                            var culture = allCountries[i];
                            html += "<option value='" + culture.TwoLetterISORegionName + "'>" + culture.DisplayName + "</option>"
                        }
                        select.innerHTML = html
                    })
                }(parent.querySelector("#selectCountry"))];
                return function (parent) {
                    var options = [{
                        name: globalize.translate("ValueSeconds", 10),
                        value: 10,
                        selected: ' selected="selected"'
                    }, {
                        name: globalize.translate("ChapterMarkers"),
                        value: -1
                    }];
                    parent.querySelector(".selectThumbnailInterval").innerHTML = options.map(function (o) {
                        return "<option" + (o.selected || "") + ' value="' + o.value + '">' + o.name + "</option>"
                    }).join("")
                }(parent), Promise.all(responses).then(function () {
                    return setContentType(parent, contentType).then(function () {
                        libraryOptions && setLibraryOptions(parent, libraryOptions), triggerElementEvents(parent), onMetadataFetchersOrReadersChange.call(parent.querySelector(".metadataFetchers")),
                            function (parent) {
                                parent.querySelector(".metadataReaders").addEventListener("click", onSortableContainerClick), parent.querySelector(".subtitleFetchers").addEventListener("click", onSortableContainerClick), parent.querySelector(".lyricsFetchers").addEventListener("click", onSortableContainerClick), parent.querySelector(".metadataFetchers").addEventListener("click", onSortableContainerClick), parent.querySelector(".imageFetchers").addEventListener("click", onImageFetchersContainerClick), parent.querySelector(".selectThumbnailImages").addEventListener("change", onThumbnailScheduleChange), parent.querySelector(".selectThumbnailInterval").addEventListener("change", onThumbnailIntervalChange), parent.querySelector(".chkImportCollections").addEventListener("change", onImportCollectionsChange), parent.querySelector(".metadataReaders").addEventListener("change", onMetadataFetchersOrReadersChange), parent.querySelector(".metadataFetchers").addEventListener("change", onMetadataFetchersOrReadersChange)
                            }(parent)
                    })
                })
            })
        },
        setContentType: setContentType,
        getLibraryOptions: function (parent) {
            var options = {
                EnableArchiveMediaFiles: !1,
                EnablePhotos: parent.querySelector(".chkEnablePhotos").checked,
                ImportPlaylists: parent.querySelector(".chkImportPlaylists").checked,
                EnableRealtimeMonitor: parent.querySelector(".chkEnableRealtimeMonitor").checked,
                ExtractChapterImagesDuringLibraryScan: "scanandtask" === parent.querySelector(".selectThumbnailImages").value,
                EnableChapterImageExtraction: !!parent.querySelector(".selectThumbnailImages").value,
                EnableMarkerDetectionDuringLibraryScan: "scanandtask" === parent.querySelector(".selectIntroDetection").value,
                EnableMarkerDetection: !!parent.querySelector(".selectIntroDetection").value,
                SaveLocalThumbnailSets: parent.querySelector(".chkLocalThumbnailSets").checked,
                ThumbnailImagesIntervalSeconds: parent.querySelector(".selectThumbnailInterval").value,
                DownloadImagesInAdvance: parent.querySelector("#chkDownloadImagesInAdvance").checked,
                EnableInternetProviders: !0,
                ImportMissingEpisodes: parent.querySelector("#chkImportMissingEpisodes").checked,
                SaveLocalMetadata: parent.querySelector("#chkSaveLocal").checked,
                EnableAutomaticSeriesGrouping: parent.querySelector(".chkAutomaticallyGroupSeries").checked,
                PreferredMetadataLanguage: parent.querySelector("#selectLanguage").value,
                PreferredImageLanguage: parent.querySelector("#selectImageLanguage").value,
                MetadataCountryCode: parent.querySelector("#selectCountry").value,
                SeasonZeroDisplayName: parent.querySelector("#txtSeasonZeroName").value,
                AutomaticRefreshIntervalDays: parseInt(parent.querySelector("#selectAutoRefreshInterval").value),
                EnableEmbeddedTitles: parent.querySelector("#chkEnableEmbeddedTitles").checked,
                SkipSubtitlesIfEmbeddedSubtitlesPresent: parent.querySelector("#chkSkipIfGraphicalSubsPresent").checked,
                SkipSubtitlesIfAudioTrackMatches: parent.querySelector("#chkSkipIfAudioTrackPresent").checked,
                SaveSubtitlesWithMedia: parent.querySelector("#chkSaveSubtitlesLocally").checked,
                SaveLyricsWithMedia: parent.querySelector("#chkSaveLyricsLocally").checked,
                SubtitleDownloadMaxAgeDays: parent.querySelector(".selectSubtitleDownloadMaxAge").value,
                LyricsDownloadMaxAgeDays: parent.querySelector(".selectLyricsDownloadMaxAge").value,
                RequirePerfectSubtitleMatch: parent.querySelector(".chkRequireHashMatch").checked,
                ForcedSubtitlesOnly: parent.querySelector(".chkForcedSubtitlesOnly").checked,
                EnableAudioResume: parent.querySelector(".chkEnableAudioResume").checked,
                MinResumePct: parent.querySelector("#txtMinResumePct").value,
                MaxResumePct: parent.querySelector("#txtMaxResumePct").value,
                MinResumeDurationSeconds: parent.querySelector("#txtMinResumeDuration").value,
                MusicFolderStructure: parent.querySelector(".selectMusicFolderStructure").value || null,
                ImportCollections: parent.querySelector(".chkImportCollections").checked,
                SaveMetadataHidden: parent.querySelector(".chkSaveMetadataHidden").checked,
                EnableAdultMetadata: parent.querySelector(".chkAdult").checked,
                MinCollectionItems: parseInt(parent.querySelector(".selectMinCollectionSize").value),
                MetadataSavers: Array.prototype.map.call(Array.prototype.filter.call(parent.querySelectorAll(".chkMetadataSaver"), function (elem) {
                    return elem.checked
                }), function (elem) {
                    return elem.getAttribute("data-pluginname")
                }),
                TypeOptions: []
            };
            return options.LocalMetadataReaderOrder = Array.prototype.map.call(parent.querySelectorAll(".localReaderOption"), function (elem) {
                    return elem.getAttribute("data-pluginname")
                }), options.SubtitleDownloadLanguages = Array.prototype.map.call(Array.prototype.filter.call(parent.querySelectorAll(".subtitleDownloadLanguages .chkLanguage"), function (elem) {
                    return elem.checked
                }), function (elem) {
                    return elem.getAttribute("data-lang")
                }), options.LyricsDownloadLanguages = Array.prototype.map.call(Array.prototype.filter.call(parent.querySelectorAll(".lyricsDownloadLanguages .chkLanguage"), function (elem) {
                    return elem.checked
                }), function (elem) {
                    return elem.getAttribute("data-lang")
                }),
                function (parent, options) {
                    options.DisabledLocalMetadataReaders = Array.prototype.map.call(Array.prototype.filter.call(parent.querySelectorAll(".chkMetadataReader"), function (elem) {
                        return !elem.checked
                    }), function (elem) {
                        return elem.getAttribute("data-pluginname")
                    })
                }(parent, options),
                function (parent, options) {
                    options.DisabledSubtitleFetchers = Array.prototype.map.call(Array.prototype.filter.call(parent.querySelectorAll(".chkSubtitleFetcher"), function (elem) {
                        return !elem.checked
                    }), function (elem) {
                        return elem.getAttribute("data-pluginname")
                    }), options.SubtitleFetcherOrder = Array.prototype.map.call(parent.querySelectorAll(".subtitleFetcherItem"), function (elem) {
                        return elem.getAttribute("data-pluginname")
                    })
                }(parent, options),
                function (parent, options) {
                    options.DisabledLyricsFetchers = Array.prototype.map.call(Array.prototype.filter.call(parent.querySelectorAll(".chkLyricsFetcher"), function (elem) {
                        return !elem.checked
                    }), function (elem) {
                        return elem.getAttribute("data-pluginname")
                    }), options.LyricsFetcherOrder = Array.prototype.map.call(parent.querySelectorAll(".lyricsFetcherItem"), function (elem) {
                        return elem.getAttribute("data-pluginname")
                    })
                }(parent, options),
                function (parent, options) {
                    for (var sections = parent.querySelectorAll(".metadataFetcher"), i = 0, length = sections.length; i < length; i++) {
                        var section = sections[i],
                            type = section.getAttribute("data-type"),
                            typeOptions = getTypeOptions(options, type);
                        typeOptions || options.TypeOptions.push(typeOptions = {
                            Type: type
                        }), typeOptions.MetadataFetchers = Array.prototype.map.call(Array.prototype.filter.call(section.querySelectorAll(".chkMetadataFetcher"), function (elem) {
                            return elem.checked
                        }), function (elem) {
                            return elem.getAttribute("data-pluginname")
                        }), typeOptions.MetadataFetcherOrder = Array.prototype.map.call(section.querySelectorAll(".metadataFetcherItem"), function (elem) {
                            return elem.getAttribute("data-pluginname")
                        })
                    }
                }(parent, options),
                function (parent, options) {
                    for (var sections = parent.querySelectorAll(".imageFetcher"), i = 0, length = sections.length; i < length; i++) {
                        var section = sections[i],
                            type = section.getAttribute("data-type"),
                            typeOptions = getTypeOptions(options, type);
                        typeOptions || options.TypeOptions.push(typeOptions = {
                            Type: type
                        }), typeOptions.ImageFetchers = Array.prototype.map.call(Array.prototype.filter.call(section.querySelectorAll(".chkImageFetcher"), function (elem) {
                            return elem.checked
                        }), function (elem) {
                            return elem.getAttribute("data-pluginname")
                        }), typeOptions.ImageFetcherOrder = Array.prototype.map.call(section.querySelectorAll(".imageFetcherItem"), function (elem) {
                            return elem.getAttribute("data-pluginname")
                        })
                    }
                }(parent, options),
                function (options) {
                    for (var originalTypeOptions = (currentLibraryOptions || {}).TypeOptions || [], i = 0, length = originalTypeOptions.length; i < length; i++) {
                        var originalTypeOption = originalTypeOptions[i],
                            typeOptions = getTypeOptions(options, originalTypeOption.Type);
                        typeOptions || (typeOptions = {
                            Type: originalTypeOption.Type
                        }, options.TypeOptions.push(typeOptions)), originalTypeOption.ImageOptions && (typeOptions.ImageOptions = originalTypeOption.ImageOptions)
                    }
                }(options), options
        },
        setLibraryOptions: setLibraryOptions,
        setAdvancedVisible: function (parent, visible) {
            for (var elems = parent.querySelectorAll(".advanced"), i = 0, length = elems.length; i < length; i++) visible ? elems[i].classList.remove("advancedHide") : elems[i].classList.add("advancedHide")
        }
    }
});