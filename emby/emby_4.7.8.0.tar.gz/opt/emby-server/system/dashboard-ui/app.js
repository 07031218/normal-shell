! function () {
    "use strict";

    function returnFirstDependency(obj) {
        return obj
    }

    function returnFirstDependencyDefault(obj) {
        return (obj = Array.isArray(obj) ? obj[0] : obj).default || obj
    }

    function enableNativeGamepadKeyMapping() {
        return window.navigator && "string" == typeof window.navigator.gamepadInputEmulation && (window.navigator.gamepadInputEmulation = "keyboard")
    }

    function loadPlugin(url) {
        return Promise.all([importFromPath("./modules/common/pluginmanager.js")]).then(function (responses) {
            var pluginManager = responses[0];
            return url.startsWith("./") && url.endsWith(".js") ? (console.log("Loading plugin module: " + url), getDynamicImport(url)().then(function (f) {
                return pluginManager.loadPlugin(f, url)
            })) : pluginManager.loadPluginFromUrl(url)
        })
    }

    function returnFalse() {
        return !1
    }

    function initializeApiClient(apiClient) {
        "ios" !== self.appMode && "android" !== self.appMode || (apiClient._getAvailablePlugins = apiClient.getAvailablePlugins, apiClient.getAvailablePlugins = function () {
            var promises = [this._getAvailablePlugins(), importFromPath("./modules/common/pluginmanager.js")];
            return Promise.all(promises).then(function (responses) {
                var plugins = responses[0],
                    pluginManager = responses[1];
                return plugins.filter(function (p) {
                    return pluginManager.allowPluginPages(p.guid)
                })
            })
        }.bind(apiClient)), Promise.all([importFromPath("./modules/browser.js")]).then(function (responses) {
            responses[0].operaTv && (apiClient.isWebSocketSupported = returnFalse)
        })
    }

    function onApiClientCreated(e, newApiClient) {
        initializeApiClient(newApiClient), window.$ && (window.$.ajax = newApiClient.ajax)
    }

    function validateServerAddressWithEndpoint(connectionManager, ajax, url, endpoint) {
        return ajax({
            url: connectionManager.getEmbyServerUrl(url, endpoint),
            timeout: 5e3,
            type: "GET",
            dataType: "text"
        }).then(function (result) {
            return -1 !== (result || "").toLowerCase().indexOf(String.fromCharCode(106) + String.fromCharCode(101) + String.fromCharCode(108) + String.fromCharCode(108)) ? Promise.reject() : Promise.resolve()
        })
    }

    function validateServerAddress(connectionManager, ajax, url) {
        return Promise.resolve();
    }
    var localApiClient;

    function getCapabilities() {
        return Promise.all([importFromPath("./modules/common/servicelocator.js")]).then(function (responses) {
            var appHost = responses[0].appHost;
            return (appHost.getSyncProfile ? appHost.getSyncProfile() : Promise.resolve(null)).then(function (deviceProfile) {
                var caps = {
                    PlayableMediaTypes: ["Audio", "Video"],
                    SupportedCommands: ["MoveUp", "MoveDown", "MoveLeft", "MoveRight", "PageUp", "PageDown", "PreviousLetter", "NextLetter", "ToggleOsd", "ToggleContextMenu", "Select", "Back", "SendKey", "SendString", "GoHome", "GoToSettings", "VolumeUp", "VolumeDown", "Mute", "Unmute", "ToggleMute", "SetVolume", "SetAudioStreamIndex", "SetSubtitleStreamIndex", "RefreshMediaSource", "DisplayContent", "GoToSearch", "DisplayMessage", "SetRepeatMode", "SetSubtitleOffset", "SetPlaybackRate", "ChannelUp", "ChannelDown", "PlayMediaSource", "PlayTrailers"],
                    SupportsMediaControl: !0
                };
                return caps.DeviceProfile = deviceProfile, caps.IconUrl = appHost.deviceIconUrl ? appHost.deviceIconUrl() : null, caps.SupportsSync = appHost.supports("sync"), caps.SupportsContentUploading = appHost.supports("cameraupload"), caps = appHost.getPushTokenInfo ? Object.assign(caps, appHost.getPushTokenInfo()) : caps
            })
        })
    }

    function createConnectionManager() {
        return Promise.all([importFromPath("./modules/emby-apiclient/connectionmanager.js"), importFromPath("./modules/emby-apiclient/events.js"), importFromPath("./modules/emby-apiclient/credentials.js"), importFromPath("./modules/querystring/querystring.js"), importFromPath("./modules/common/usersettings/usersettings.js"), importFromPath("./modules/common/servicelocator.js"), require(["apiclient"]), require(["wakeOnLan"])]).then(function (outerResponses) {
            var connectionManager = outerResponses[0],
                events = outerResponses[1],
                credentialProvider = outerResponses[2],
                queryString = outerResponses[3],
                userSettings = outerResponses[4],
                serviceLocator = outerResponses[5],
                apiClientFactory = outerResponses[6][0],
                wakeOnLan = outerResponses[7][0],
                apphost = serviceLocator.appHost,
                appStorage = serviceLocator.appStorage,
                credentialProviderInstance = (self.Events = events, new credentialProvider(appStorage)),
                outerResponses = [];
            return apphost.supports("sync") ? outerResponses.push(require(["localassetmanager", "itemrepository", "useractionrepository"])) : outerResponses.push(Promise.resolve([])), outerResponses.push(apphost.init()), Promise.all(outerResponses).then(function (responses) {
                var name, accessToken, userId, localassetmanager = responses[0][0],
                    itemrepository = responses[0][1],
                    responses = responses[0][2];
                connectionManager.initialize(credentialProviderInstance, appStorage, apiClientFactory, (name = "serverdiscovery", function () {
                        return require([name]).then(function (responses) {
                            return returnFirstDependencyDefault(responses[0])
                        })
                    }), wakeOnLan, apphost.appName(), apphost.appVersion(), apphost.deviceName(), apphost.deviceId(), getCapabilities, self.devicePixelRatio, localassetmanager, itemrepository, responses), self.ConnectionManager = connectionManager,
                    function (connectionManager, events, userSettings, appHost) {
                        events.on(connectionManager, "apiclientcreated", onApiClientCreated), connectionManager.currentApiClient = function () {
                            var server;
                            return localApiClient || (server = connectionManager.getLastUsedServer()) && (localApiClient = connectionManager.getApiClient(server.Id)), localApiClient
                        }, connectionManager.onLocalUserSignedIn = function (serverId, userId) {
                            return localApiClient = connectionManager.getApiClient(serverId), self.ApiClient = localApiClient, userSettings.setUserInfo(userId, localApiClient)
                        }, events.on(connectionManager, "localusersignedout", function () {
                            userSettings.setUserInfo(null, null)
                        }), appHost.supports("multiserver") && (connectionManager.validateServerAddress = validateServerAddress)
                    }(self.ConnectionManager = connectionManager, events, userSettings, apphost), apphost.supports("multiserver") || (window.location.search && (accessToken = (localassetmanager = queryString.parse(window.location.search)).accessToken, userId = localassetmanager.userId, accessToken && userId && 1 === localassetmanager.e || (userId = accessToken = null)), console.log("creating ApiClient singleton"), connectionManager.validateServerIds = !1, itemrepository = window.location.href.toLowerCase(), localassetmanager = -1 !== (responses = itemrepository.lastIndexOf("/web")) ? itemrepository.substring(0, responses) : (itemrepository = window.location, responses = itemrepository.protocol + "//" + itemrepository.hostname, itemrepository.port && (responses += ":" + itemrepository.port), responses), itemrepository = connectionManager.getApiClientFromServerInfo({
                        ManualAddress: localassetmanager,
                        ManualAddressOnly: !0,
                        IsLocalServer: !0,
                        AccessToken: accessToken,
                        UserId: userId
                    }, localassetmanager), accessToken && userId && (window.location = "index.html"), itemrepository.enableAutomaticNetworking = !1, self.ApiClient = itemrepository, localApiClient = itemrepository, console.log("loaded ApiClient singleton"))
            })
        })
    }

    function getPluginPageContentPath() {
        return self.ApiClient ? self.ApiClient.getUrl("web/ConfigurationPage") : null
    }

    function triggerWorkerTask() {
        require(["bgtaskregister"], function (bgtaskregister) {
            try {
                bgtaskregister.triggerTask()
            } catch (err) {
                console.error("Error firing ApplicationTrigger", err)
            }
        })
    }

    function getWindowsLocalSync() {
        return {
            sync: triggerWorkerTask,
            setProgressUpdatesEnabled: function (enabled) {}
        }
    }

    function getDynamicImportWithoutExport(path) {
        return function () {
            return require(["".concat(path)])
        }
    }

    function getDynamicImport(path) {
        return function () {
            return require(["".concat(path)]).then(returnFirstDependencyDefault)
        }
    }

    function importFromPath(path) {
        return getDynamicImport(path)()
    }

    function importFromPathWithoutExport(path) {
        return getDynamicImportWithoutExport(path)()
    }

    function loadAppStorage() {
        var promise;
        if ("winjs" === self.appMode) promise = require(["native/windows/appstorage"]);
        else try {
            localStorage.setItem("_test", "0"), localStorage.removeItem("_test"), promise = getDynamicImport("./modules/emby-apiclient/appstorage-localstorage.js")()
        } catch (e) {
            promise = getDynamicImport("./modules/emby-apiclient/appstorage-memory.js")()
        }
        return promise.then(function (appStorage) {
            return ((appStorage = returnFirstDependencyDefault(appStorage)).init ? appStorage.init() : Promise.resolve()).then(function () {
                return appStorage
            })
        })
    }

    function loadWebFullscreenManager(serviceLocator) {
        return getDynamicImport("./modules/fullscreen/fullscreenmanager.js")().then(function (fullscreenManager) {
            return serviceLocator.initialize({
                fullscreenManager: fullscreenManager
            }), fullscreenManager
        })
    }

    function loadFullscreenManager(fullscreenManager, serviceLocator) {
        return serviceLocator.initialize({
            fullscreenManager: fullscreenManager
        }), fullscreenManager
    }

    function loadServiceLocator() {
        return require(["appStorage", "apphost", "shell", "fullscreenManager"]).then(function (responses) {
            var appStorage = responses[0],
                appHost = responses[1],
                shell = responses[2];
            return getDynamicImport("./modules/common/servicelocator.js")().then(function (serviceLocator) {
                return serviceLocator.initialize({
                    appStorage: appStorage,
                    appHost: appHost,
                    shell: shell
                }), require(["iapManager"]).then(function (responses) {
                    var iapManager = responses[0];
                    return getDynamicImport("./modules/common/servicelocator.js")().then(function (serviceLocator) {
                        serviceLocator.initialize({
                            iapManager: iapManager
                        })
                    })
                })
            })
        })
    }

    function addJsExtIfNeeded(path) {
        return path.endsWith(".js") || (path += ".js"), path
    }

    function loadHeader() {
        return console.log("loadHeader"), Promise.all([importFromPath("./modules/appheader/appheader.js")]).then(function (responses) {
            return responses[0].init()
        })
    }

    function onAppReady() {
        "virtualKeyboard" in navigator && (navigator.virtualKeyboard.overlaysContent = !0), console.log("onAppReady");
        var promises = [importFromPath("./modules/common/servicelocator.js"), importFromPath("./modules/approuter.js"), importFromPath("./modules/browser.js")];
        return "ios" !== self.appMode && "android" !== self.appMode || promises.push(importFromPath("./modules/registrationservices/registrationservices.js")), Promise.all(promises).then(function (responses) {
            var appHost = responses[0].appHost,
                appRouter = responses[1],
                responses = responses[2],
                appRouter = (promises = [], console.log("Loaded dependencies in onAppReady"), ! function (appRouter, appHost) {
                    console.log("Defining core routes"), appRouter.addRoute({
                        path: "/startup/connectlogin.html",
                        transition: "slide",
                        controller: "startup/connectlogin",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        autoFocus: !1,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/connectsignup.html",
                        transition: "slide",
                        controller: "startup/connectsignup.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/welcome.html",
                        transition: "slide",
                        controller: "startup/welcome.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/forgotpassword.html",
                        transition: "slide",
                        controller: "startup/forgotpassword.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/forgotpasswordpin.html",
                        transition: "slide",
                        controller: "startup/forgotpasswordpin.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/home",
                        contentPath: "/home/home.html",
                        transition: "slide",
                        type: "home",
                        defaultTitle: !0,
                        controller: "home/home.js",
                        controllerType: "module",
                        autoFocus: !1,
                        homeButton: !1,
                        headerTabs: !0,
                        backdropItemTypes: "Movie,Series,Game,Book",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/home/home.html",
                        contentPath: "/home/home.html",
                        transition: "slide",
                        type: "home",
                        defaultTitle: !0,
                        controller: "home/home.js",
                        controllerType: "module",
                        autoFocus: !1,
                        homeButton: !1,
                        headerTabs: !0,
                        backdropItemTypes: "Movie,Series,Game,Book",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/home.html",
                        contentPath: "/home/home.html",
                        transition: "slide",
                        type: "home",
                        defaultTitle: !0,
                        controller: "home/home.js",
                        controllerType: "module",
                        autoFocus: !1,
                        homeButton: !1,
                        headerTabs: !0,
                        backdropItemTypes: "Movie,Series,Game,Book",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/home_horiz/home.html",
                        transition: "slide",
                        type: "home",
                        controller: "home_horiz/home",
                        autoFocus: !1,
                        homeButton: !1,
                        headerBackground: !1,
                        backdropItemTypes: "Movie,Series,Game,Book",
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/list/list.html",
                        transition: "slide",
                        controller: "list/list.js",
                        controllerType: "module",
                        autoFocus: !1,
                        canRefresh: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        supportsThemeMedia: !0
                    }), appRouter.addRoute({
                        contentPath: "/item/item.html",
                        path: "/item",
                        autoFocus: !1,
                        transition: "slide",
                        controller: "item/item",
                        transparentHeader: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        supportsThemeMedia: !0
                    }), appRouter.addRoute({
                        contentPath: "/item/item.html",
                        path: "/item/item.html",
                        controller: "item/item",
                        autoFocus: !1,
                        transition: "slide",
                        transparentHeader: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        supportsThemeMedia: !0
                    }), appRouter.addRoute({
                        contentPath: "/livetv/livetv.html",
                        path: "/livetv",
                        transition: "slide",
                        controller: "livetv/livetv",
                        autoFocus: !1,
                        headerTabs: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/login.html",
                        transition: "slide",
                        controller: "startup/login.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/manuallogin.html",
                        transition: "slide",
                        controller: "startup/manuallogin.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        autoFocus: !1,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/games/games.html",
                        path: "/games",
                        transition: "slide",
                        controller: "games/games",
                        autoFocus: !1,
                        headerTabs: !0,
                        backdropItemTypes: "Game",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/videos/videos.html",
                        path: "/videos",
                        transition: "slide",
                        controller: "videos/videos",
                        autoFocus: !1,
                        headerTabs: !0,
                        backdropItemTypes: "Movie,Series,MusicVideo,Video",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/music/music.html",
                        path: "/music",
                        transition: "slide",
                        controller: "music/music",
                        autoFocus: !1,
                        headerTabs: !0,
                        backdropItemTypes: "MusicAlbum",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/videoosd/videoosd.html",
                        transition: "fade",
                        controller: "videoosd/videoosd_view.js",
                        controllerType: "module",
                        type: "video-osd",
                        supportsThemeMedia: !0,
                        enableMediaControl: !1,
                        autoFocus: !1,
                        headerBackground: !1,
                        homeButton: !1,
                        drawer: !1,
                        dockedTabs: !1,
                        clearBackdrop: !0,
                        backButton: !0,
                        transparentHeader: !0
                    }), appRouter.addRoute({
                        contentPath: "/settings/settings.html",
                        path: "/settings",
                        transition: "slide",
                        controller: "settings/settings.js",
                        controllerType: "module",
                        title: "Settings",
                        autoFocus: !1,
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        drawer: !1,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appHost.supports("keyboardsettings") && appRouter.addRoute({
                        path: "/settings/keyboard.html",
                        transition: "slide",
                        controller: "settings/keyboard.js",
                        controllerType: "module",
                        type: "settings",
                        title: "HeaderKeyboardAndRemote",
                        thumbImage: "",
                        order: 2,
                        icon: "&#xe312;",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/settings/playback.html",
                        transition: "slide",
                        controller: "settings/playback.js",
                        controllerType: "module",
                        type: "settings",
                        title: "Playback",
                        category: "Playback",
                        thumbImage: "",
                        order: 2,
                        icon: "&#xe038;",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        settingsType: "user",
                        adjustHeaderForEmbeddedScroll: !0,
                        hideDrawerWithOtherUserIdParam: !0
                    }), appRouter.addRoute({
                        path: "/settings/subtitles.html",
                        transition: "slide",
                        controller: "settings/subtitles.js",
                        controllerType: "module",
                        type: "settings",
                        title: "Subtitles",
                        category: "Playback",
                        thumbImage: "",
                        order: 3,
                        icon: "&#xe01c;",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        settingsType: "user",
                        adjustHeaderForEmbeddedScroll: !0,
                        hideDrawerWithOtherUserIdParam: !0
                    }), appRouter.addRoute({
                        path: "/settings/display.html",
                        transition: "slide",
                        controller: "settings/display.js",
                        controllerType: "module",
                        type: "settings",
                        title: "Display",
                        category: "General",
                        thumbImage: "",
                        order: 0,
                        icon: "&#xe333;",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        settingsType: "user",
                        adjustHeaderForEmbeddedScroll: !0,
                        hideDrawerWithOtherUserIdParam: !0
                    }), appRouter.addRoute({
                        path: "/settings/homescreen.html",
                        transition: "slide",
                        controller: "settings/homescreen.js",
                        controllerType: "module",
                        type: "settings",
                        title: "HeaderHomeScreen",
                        category: "General",
                        thumbImage: "",
                        order: 1,
                        icon: "&#xE88a;",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        settingsType: "user",
                        adjustHeaderForEmbeddedScroll: !0,
                        hideDrawerWithOtherUserIdParam: !0
                    }), appHost.supports("fileinput") && appRouter.addRoute({
                        path: "/settings/profile.html",
                        transition: "slide",
                        controller: "settings/profile.js",
                        controllerType: "module",
                        type: "settings",
                        title: "Profile",
                        icon: "person",
                        clearBackdrop: !0,
                        roles: "EnableUserPreferenceAccess",
                        settingsTheme: !0,
                        settingsType: "user",
                        adjustHeaderForEmbeddedScroll: !0,
                        hideDrawerWithOtherUserIdParam: !0
                    }), appRouter.addRoute({
                        path: "/settings/password.html",
                        transition: "slide",
                        controller: "settings/password.js",
                        controllerType: "module",
                        type: "settings",
                        title: "Password",
                        icon: "lock",
                        autoFocus: !1,
                        clearBackdrop: !0,
                        roles: "EnableUserPreferenceAccess",
                        settingsTheme: !0,
                        settingsType: "user",
                        adjustHeaderForEmbeddedScroll: !0,
                        hideDrawerWithOtherUserIdParam: !0
                    }), appHost.supports("cameraupload") && appRouter.addRoute({
                        path: "/settings/cameraupload.html",
                        autoFocus: !1,
                        transition: "slide",
                        controller: "settings/cameraupload",
                        type: "settings",
                        icon: "photo",
                        title: "HeaderCameraUpload",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159382-camera-upload",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appHost.supports("sync") && (appRouter.addRoute({
                        path: "/settings/download.html",
                        transition: "slide",
                        controller: "settings/download",
                        type: "settings",
                        icon: "download",
                        title: "Downloads",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/settings/managedownloads.html",
                        transition: "slide",
                        controller: "settings/managedownloads",
                        icon: "download",
                        type: "settings",
                        title: "HeaderManageDownloads",
                        autoFocus: !1,
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    })), appRouter.addRoute({
                        path: "/search",
                        contentPath: "/search/search.html",
                        transition: "slide",
                        controller: "search/search",
                        title: "",
                        autoFocus: !1,
                        clearBackdrop: !0,
                        searchButton: !1,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/manualserver.html",
                        transition: "slide",
                        controller: "startup/manualserver.js",
                        controllerType: "module",
                        anonymous: !0,
                        startup: !0,
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/startup/selectserver.html",
                        autoFocus: !1,
                        anonymous: !0,
                        startup: !0,
                        controller: "startup/selectserver",
                        transition: "slide",
                        defaultTitle: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/tv/tv.html",
                        path: "/tv",
                        transition: "slide",
                        controller: "tv/tv.js",
                        controllerType: "module",
                        autoFocus: !1,
                        headerTabs: !0,
                        backdropItemTypes: "Series",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appHost.supports("serversetup") && (appRouter.addRoute({
                        contentPath: "/plugins/addplugin.html",
                        path: "/plugins/install",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "plugins/addpluginpage.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159720-plugins",
                        title: "Plugins"
                    }), appRouter.addRoute({
                        path: "/database",
                        contentPath: "/server/database/database.html",
                        roles: "admin",
                        controller: "server/database/database.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        title: "Database",
                        autoFocus: !1
                    }), appRouter.addRoute({
                        path: "/dashboard",
                        contentPath: "/dashboard/dashboard.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "dashboard/dashboard",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        title: "Dashboard"
                    }), appRouter.addRoute({
                        path: "/dashboard.html",
                        contentPath: "/dashboard/dashboard.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "dashboard/dashboard",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        title: "Dashboard"
                    }), appRouter.addRoute({
                        path: "/dashboard/settings",
                        contentPath: "/dashboard/settings.html",
                        controller: "dashboard/settings.js",
                        controllerType: "module",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159322-server-settings",
                        title: "Settings",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/list/list.html",
                        path: "/devices",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "devices/devices",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159497-devices",
                        title: "Devices",
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0
                    }), appRouter.addRoute({
                        contentPath: "/network/network.html",
                        path: "/network",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "network/network.js",
                        controllerType: "module",
                        title: "Network",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159601-hosting-settings",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/devices/device.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "devices/device.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159497-devices",
                        title: "Devices",
                        navMenuId: "/devices",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/devices/cameraupload.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "devices/cameraupload.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        title: "HeaderCameraUpload",
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159382-camera-upload",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/metadatamanager/metadatamanager.html",
                        path: "/metadatamanager",
                        controller: "metadatamanager/metadatamanager.js",
                        controllerType: "module",
                        autoFocus: !1,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        title: "MetadataManager"
                    }), appRouter.addRoute({
                        contentPath: "/transcoding/transcoding.html",
                        path: "/transcoding",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "transcoding/transcoding.js",
                        controllerType: "module",
                        title: "Transcoding",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159897-transcoding",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/list/list.html",
                        path: "/librarysetup/library.html",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        controller: "librarysetup/library.js",
                        controllerType: "module",
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159319-library-setup",
                        title: "Library",
                        navMenuId: "librarysetup"
                    }), appRouter.addRoute({
                        path: "/librarysetup/advanced.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "librarysetup/advanced.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159319-library-setup",
                        title: "Library",
                        navMenuId: "librarysetup",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/livetvsetup/xmltv.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "livetvsetup/xmltv",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "LiveTV",
                        navMenuId: "livetvsetup"
                    }), appRouter.addRoute({
                        path: "/livetvsetup/embydata.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "livetvsetup/embydata",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "LiveTV",
                        navMenuId: "livetvsetup"
                    }), appRouter.addRoute({
                        path: "/livetvsetup/guideprovider.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "livetvsetup/guideprovider.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "LiveTV",
                        navMenuId: "livetvsetup"
                    }), appRouter.addRoute({
                        path: "/livetvsetup/livetvsettings.html",
                        autoFocus: !1,
                        controller: "livetvsetup/livetvsettings.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "LiveTV"
                    }), appRouter.addRoute({
                        path: "/livetvsetup/livetvstatus.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "livetvsetup/livetvstatus.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "LiveTV",
                        navMenuId: "livetvsetup"
                    }), appRouter.addRoute({
                        contentPath: "/list/list.html",
                        path: "/livetvsetup/channels",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "livetvsetup/channels",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        canRefresh: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "LiveTV"
                    }), appRouter.addRoute({
                        path: "/livetvsetup/livetvtuner.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "livetvsetup/livetvtuner.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                        title: "HeaderTVSourceSetup",
                        navMenuId: "livetvsetup"
                    }), appRouter.addRoute({
                        path: "/logs",
                        contentPath: "/list/list.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "logs/logs.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0,
                        title: "Logs"
                    }), appRouter.addRoute({
                        path: "/log",
                        contentPath: "/list/list.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "logs/log",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0,
                        title: "Logs",
                        navMenuId: "/logs"
                    }), appRouter.addRoute({
                        path: "/server/notifications/notificationsetting.html",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        controller: "server/notifications/notificationsetting.js",
                        controllerType: "module",
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159719-notifications",
                        title: "Notifications",
                        navMenuId: "notifications"
                    }), appRouter.addRoute({
                        path: "/server/notifications/notificationsettings.html",
                        controller: "server/notifications/notificationsettings.js",
                        controllerType: "module",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159719-notifications",
                        title: "Notifications",
                        navMenuId: "notifications"
                    }), appRouter.addRoute({
                        path: "/plugincatalog",
                        contentPath: "/plugins/plugincatalog.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "plugins/plugincatalog.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159720-plugins",
                        title: "Plugins",
                        navMenuId: "/plugins",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        contentPath: "/list/list.html",
                        path: "/plugins",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "plugins/plugins.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159720-plugins",
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0,
                        title: "Plugins"
                    }), appRouter.addRoute({
                        path: "/scheduledtask",
                        contentPath: "/scheduledtasks/scheduledtask.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "scheduledtasks/scheduledtask.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159751-scheduled-tasks",
                        title: "HeaderScheduledTasks",
                        navMenuId: "/scheduledtasks",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/dashboard/releasenotes.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "dashboard/releasenotes.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/scheduledtasks",
                        contentPath: "/scheduledtasks/scheduledtasks.html",
                        roles: "admin",
                        autoFocus: !1,
                        controller: "scheduledtasks/scheduledtasks.js",
                        controllerType: "module",
                        title: "HeaderScheduledTasks",
                        clearBackdrop: !0,
                        settingsTheme: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159751-scheduled-tasks",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/serveractivity",
                        contentPath: "/list/list.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "dashboard/serveractivity.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0,
                        navMenuId: "/dashboard"
                    }), appRouter.addRoute({
                        path: "/apikeys",
                        contentPath: "/list/list.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "apikeys/apikeys",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0,
                        title: "HeaderApiKeys"
                    }), appRouter.addRoute({
                        contentPath: "/embypremiere/embypremiere.html",
                        path: "/embypremiere",
                        controller: "embypremiere/embypremiere.js",
                        controllerType: "module",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://emby.media/premiere",
                        title: "Emby Premiere",
                        adjustHeaderForEmbeddedScroll: !0
                    }), appRouter.addRoute({
                        path: "/serverdownloads",
                        contentPath: "server/downloads/activity.html",
                        autoFocus: !1,
                        controller: "server/downloads/activity.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        title: "Downloads"
                    }), appRouter.addRoute({
                        path: "/conversions",
                        contentPath: "server/downloads/activity.html",
                        autoFocus: !1,
                        controller: "server/downloads/activity.js",
                        controllerType: "module",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        title: "Conversions"
                    }), appRouter.addRoute({
                        path: "/serverdownloadsettings",
                        contentPath: "server/downloads/settings.html",
                        autoFocus: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        controller: "server/downloads/settings.js",
                        controllerType: "module"
                    }), appRouter.addRoute({
                        path: "/users/user",
                        contentPath: "/users/user.html",
                        controller: "users/user.js",
                        controllerType: "module",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        headerTabs: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160237-users",
                        navMenuId: "/users"
                    }), appRouter.addRoute({
                        path: "/users/new",
                        contentPath: "/users/usernew.html",
                        controller: "users/usernew.js",
                        controllerType: "module",
                        autoFocus: !1,
                        roles: "admin",
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160237-users",
                        navMenuId: "/users",
                        title: "Users"
                    }), appRouter.addRoute({
                        path: "/users",
                        contentPath: "/list/list.html",
                        autoFocus: !1,
                        roles: "admin",
                        controller: "users/users",
                        settingsTheme: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001160237-users",
                        adjustHeaderForEmbeddedScroll: !0,
                        canRefresh: !0,
                        title: "Users"
                    }), appRouter.addRoute({
                        path: "/wizard/wizardagreement.html",
                        anonymous: !0,
                        controller: "wizard/wizardagreement.js",
                        controllerType: "module",
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/wizard/wizardremoteaccess.html",
                        anonymous: !0,
                        controller: "wizard/wizardremoteaccess.js",
                        controllerType: "module",
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/wizard/wizardfinish.html",
                        anonymous: !0,
                        controller: "wizard/wizardfinishpage.js",
                        controllerType: "module",
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/wizard/wizardlibrary.html",
                        controller: "librarysetup/library.js",
                        controllerType: "module",
                        anonymous: !0,
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0,
                        helpUrl: "https://support.emby.media/support/solutions/articles/44001159319-library-setup"
                    }), appRouter.addRoute({
                        path: "/wizard/wizardsettings.html",
                        anonymous: !0,
                        controller: "wizard/wizardsettings.js",
                        controllerType: "module",
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/wizard/wizardstart.html",
                        anonymous: !0,
                        controller: "wizard/wizardstart.js",
                        controllerType: "module",
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/wizard/wizarduser.html",
                        controller: "wizard/wizarduserpage.js",
                        controllerType: "module",
                        autoFocus: !1,
                        anonymous: !0,
                        homeButton: !1,
                        secondaryHeaderFeatures: !1,
                        defaultTitle: !0,
                        drawer: !1,
                        dockedTabs: !1,
                        settingsTheme: !0,
                        adjustHeaderForEmbeddedScroll: !0,
                        clearBackdrop: !0
                    }), appRouter.addRoute({
                        path: "/configurationpage",
                        autoFocus: !1,
                        enableCache: !1,
                        enableContentQueryString: !0,
                        roles: "admin",
                        contentPath: appHost.supports("multiserver") ? getPluginPageContentPath : null,
                        settingsTheme: !0,
                        windowScroll: 3,
                        requiresDynamicTitle: !0
                    })), appRouter.addRoute({
                        path: "/index.html",
                        isDefaultRoute: !0,
                        transition: "slide",
                        clearBackdrop: !0,
                        autoFocus: !1
                    }), appRouter.addRoute({
                        path: "/",
                        isDefaultRoute: !0,
                        transition: "slide",
                        clearBackdrop: !0
                    })
                }(appRouter, appHost), appRouter.start({
                    click: !1,
                    hashbang: !0
                }), document.dispatchEvent(new CustomEvent("appready", {})), []);
            appHost.supports("soundeffects") && promises.push(importFromPath("./modules/soundeffects/soundeffectsmanager.js")), appRouter.push("thememediaplayer"), !enableNativeGamepadKeyMapping() && ("ongamepadconnected" in window || navigator.getGamepads || navigator.webkitGetGamepads) && appRouter.push("gamepadtokey"), appHost.supports("windowstate") && getDynamicImportWithoutExport("./modules/controlbox.js")(), "android" === self.appMode ? (appRouter.push("native/android/mediasession"), appRouter.push("native/android/chromecast"), appRouter.push("native/android/appshortcuts"), appRouter.push("native/android/nativecredentials"), appRouter.push("native/android/nativesettings")) : "ios" === self.appMode ? (appRouter.push("native/ios/mediasession"), appRouter.push("native/ios/statusbar"), appRouter.push("native/ios/appshortcuts"), appRouter.push("native/ios/backgroundfetch"), appRouter.push("native/ios/nativecredentials"), appRouter.push("native/ios/nativesettings"), appRouter.push("native/ios/nativeplayerbridge")) : "windows" === self.appMode ? (appRouter.push("native/windows/mediasession"), appRouter.push("native/windows/nativesettings"), appRouter.push("native/windows/nativecredentials")) : self.tizen ? (require(["css!native/tizen/style"]), require(["native/tizen/tizeninfo"]), require(["native/tizen/input"]), require(["native/tizen/networkerror"]), responses.sdkVersion && 2.4 <= responses.sdkVersion && require(["native/tizen/preview"]), require(["native/tizen/screensavermanager"]), responses.tizenSideload = !1, responses.tizenSideload && require(["native/tizen/expiration"])) : (self.webos || self.PalmSystem) && (require(["native/webos/webOSTV"]), require(["native/webos/webosinfo"])), responses.tv || (getDynamicImportWithoutExport("./modules/autobackdrops.js")(), screen.orientation && screen.orientation.lock && getDynamicImportWithoutExport("./modules/playback/playbackorientation.js")(), getDynamicImportWithoutExport("./modules/nowplayingbar/nowplayingbar.js")(), getDynamicImportWithoutExport("./modules/notifications.js")(), promises.push(importFromPath("./modules/dockedtabs/dockedtabs.js"))), appHost.supports("remotecontrol") && getDynamicImportWithoutExport("./modules/playback/remotecontrolautoplay.js")(), appHost.supports("nativevolumeosd") || getDynamicImportWithoutExport("./modules/playback/volumeosd.js")(), navigator.mediaSession && appRouter.push("mediaSession"), appRouter.push("mouseManager"), getDynamicImportWithoutExport("./modules/input/keyboard.js")(), appRouter.push("apiInput"), appHost.supports("screensaver") && appRouter.push("screensaverManager"), appHost.supports("fullscreenchange") && getDynamicImportWithoutExport("./modules/fullscreen/fullscreen-dc.js")(), require(appRouter), appHost.supports("multiserver") || self.ApiClient && require(["css!" + self.ApiClient.getUrl("Branding/Css")]), "winjs" === self.appMode && function (appHost) {
                navigator.mediaSession || require(["native/windows/mediasession"]), navigator.connection && navigator.connection.type || require(["native/windows/networkpolyfill"]), appHost.supports("sync") && require(["bgtaskregister"], function (bgtaskregister) {
                    bgtaskregister.registerTask()
                })
            }(appHost), getDynamicImport("./modules/common/playback/playbackmanager.js")().then(function (playbackManager) {
                window.addEventListener("beforeunload", function (e) {
                    try {
                        playbackManager.onAppClose()
                    } catch (err) {
                        console.log("error in onAppClose: " + err)
                    }
                })
            })
        })
    }

    function loadFirstLevelPresentationDependencies() {
        return console.log("loadFirstLevelPresentationDependencies"), Promise.all([importFromPath("./modules/browser.js")]).then(function (responses) {
            responses[0].osx ? document.documentElement.classList.add("html-osx") : "windows" !== self.appMode && "winjs" !== self.appMode || document.documentElement.classList.add("html-maxfonttouch");
            responses = [];
            return responses.push(require(["layoutStyle"])), responses.push(require(["flexStyles"])), responses.push(require(["sectionsStyle"])), responses.push(require(["systemFontsCss"])), Promise.all(responses)
        })
    }

    function loadGlobalization() {
        return Promise.all([importFromPath("./modules/common/globalize.js"), importFromPath("./modules/common/servicelocator.js")]).then(function (responses) {
            var globalize = responses[0],
                responses = responses[1].appHost,
                stringPromises = (self.urlCacheParam && globalize.setCacheParam(self.urlCacheParam), []);
            return responses.supports("serversetup") && stringPromises.push(function (globalize) {
                var translations = ["ar", "be-BY", "bg-BG", "ca", "cs", "da", "de", "el", "en-GB", "en-US", "es", "es-AR", "es-MX", "fa", "fi", "fr", "fr-CA", "gsw", "he", "hi-IN", "hr", "hu", "id", "it", "ja", "kk", "ko", "lt-LT", "ms", "nb", "nl", "pl", "pt-BR", "pt-PT", "ro", "ru", "sk", "sl-SI", "sv", "tr", "uk", "vi", "zh-CN", "zh-HK", "zh-TW"].map(function (i) {
                    return {
                        lang: i,
                        path: "strings/" + i + ".json"
                    }
                });
                return globalize.loadStrings({
                    name: "core",
                    translations: translations
                })
            }(globalize)), stringPromises.push(function (globalize) {
                var translations = ["ar", "bg-BG", "ca", "cs", "da", "de", "el", "en-GB", "en-US", "es", "es-AR", "es-MX", "et-EE", "fi", "fr", "fr-CA", "gsw", "he", "hr", "hu", "id", "it", "ja", "kk", "ko", "lt-LT", "ms", "nb", "nl", "pl", "pt-BR", "pt-PT", "ro", "ru", "sk", "sl-SI", "sv", "tr", "uk", "vi", "zh-CN", "zh-HK", "zh-TW"].map(function (i) {
                    return {
                        lang: i,
                        path: "modules/common/strings/" + i + ".json"
                    }
                });
                return globalize.loadStrings({
                    name: "sharedcomponents",
                    translations: translations
                })
            }(globalize)), Promise.all(stringPromises)
        })
    }

    function loadThirdLevelPolyfills() {
        return Promise.all([importFromPath("./modules/browser.js")]).then(function (responses) {
            var responses = responses[0],
                promises = [];
            return "customElements" in self ? "customElements" in self && !responses.iOS && !responses.safari && customElements.upgrade || promises.push(require(["modules/polyfills/custom-elements-builtin"])) : self.MutationObserver && self.Reflect ? promises.push(require(["modules/polyfills/custom-elements"])) : promises.push(require(["modules/polyfills/document-register-element"])), Promise.all(promises)
        })
    }

    function loadSecondLevelPolyfills() {
        var list = [],
            promises = [];
        return self.SpeechRecognition || (self.SpeechRecognition = self.webkitSpeechRecognition), "undefined" != typeof AbortController && "undefined" != typeof AbortSignal && ("function" != typeof self.Request || self.Request.prototype.hasOwnProperty("signal")) && self.AbortController || list.push("bower_components/abortcontroller-polyfill/umd-polyfill"), self.Intl && self.Intl.NumberFormat || list.push("modules/polyfills/numberformat"), "function" == typeof Object.assign && "function" == typeof Object.create || list.push("modules/polyfills/object"), "function" == typeof Promise.any && "function" == typeof Promise.allSettled || list.push("modules/polyfills/promise"), String.prototype.includes && String.prototype.startsWith && String.prototype.endsWith && String.prototype.replaceAll || list.push("modules/polyfills/string"), Array.prototype.filter && Array.prototype.includes && Array.prototype.some && Array.isArray || list.push("modules/polyfills/array"), Element.prototype.matches && Element.prototype.closest && Element.prototype.remove || list.push("modules/polyfills/element"), HTMLFormElement.prototype.requestSubmit || list.push("modules/polyfills/form"), Function.prototype.bind || list.push("modules/polyfills/bind"), "undefined" == typeof Map && list.push("modules/polyfills/map"), "undefined" == typeof WeakMap && promises.push(importFromPathWithoutExport("./modules/polyfills/weakmap.js")), "undefined" == typeof Set && list.push("modules/polyfills/set"), self.crypto && crypto.randomUUID || promises.push(importFromPathWithoutExport("./modules/polyfills/crypto.js")), self.CSS && CSS.supports || promises.push(importFromPathWithoutExport("./modules/polyfills/css.js")), Promise.all([require(list), Promise.all(promises)])
    }

    function loadFirstLevelPolyfills(responses) {
        responses = responses[0];
        if (responses.msie) return document.documentElement.classList.remove("preload"), document.documentElement.style.background = "white", document.body.style.background = "white", document.body.innerHTML = 'The Emby web app doesn\'t work with Internet Explorer. Please use a modern web browser such as <a target="_blank" href="https://www.microsoft.com/edge">Microsoft Edge</a>, <a target="_blank" href="https://google.com/chrome">Google Chrome</a>, <a target="_blank" href="https://getfirefox.com">Firefox</a>, <a target="_blank" href="https://opera.com">Opera</a>, or <a href="https://en.wikipedia.org/wiki/List_of_web_browsers" target="_blank">other</a>.', Promise.reject();
        (self.appMode || responses.tv) && (console.log = function () {});
        var supportsSync = !0,
            responses = ("windows" === self.appMode ? (define("transfermanager", [], getDynamicImport("./modules/sync/transfermanager.js")), define("filerepository", ["native/windows/filerepository"], returnFirstDependency), define("localsync", ["native/windows/localsync"], returnFirstDependency), define("itemrepository", ["native/windows/itemrepository"], returnFirstDependency), define("useractionrepository", ["native/windows/useractionrepository"], returnFirstDependency)) : "winjs" !== self.appMode || responses.xboxOne ? "ios" === self.appMode ? (define("filerepository", ["native/ios/filerepository"], returnFirstDependency), define("transfermanager", ["filerepository"], returnFirstDependency), define("localsync", ["native/ios/localsync"], returnFirstDependency), define("itemrepository", ["native/ios/itemrepository"], returnFirstDependency), define("useractionrepository", ["native/ios/useractionrepository"], returnFirstDependency)) : "android" === self.appMode && AndroidAppHost.supportsSync() ? (define("transfermanager", [], getDynamicImport("./modules/sync/transfermanager.js")), define("filerepository", ["native/android/filerepository"], returnFirstDependency), define("localsync", ["native/android/localsync"], returnFirstDependency), define("itemrepository", ["native/android/itemrepository"], returnFirstDependency), define("useractionrepository", ["native/android/useractionrepository"], returnFirstDependency)) : (define("transfermanager", [], getDynamicImport("./modules/sync/transfermanager.js")), define("filerepository", [], getDynamicImport("./modules/sync/filerepository.js")), define("localsync", [], getDynamicImport("./modules/sync/localsync.js")), define("itemrepository", [], getDynamicImport("./modules/localdatabase/itemrepository.js")), define("useractionrepository", [], getDynamicImport("./modules/localdatabase/useractionrepository.js")), supportsSync = !1) : (define("bgtaskregister", ["native/windows/bgtaskregister"], returnFirstDependency), define("transfermanager", ["native/windows/transfermanager"], returnFirstDependency), define("filerepository", ["native/windows/filerepository"], returnFirstDependency), define("localsync", [], getWindowsLocalSync), define("itemrepository", [], getDynamicImport("./modules/localdatabase/itemrepository.js")), define("useractionrepository", [], getDynamicImport("./modules/localdatabase/useractionrepository.js"))), supportsSync ? define("apiclient", [], getDynamicImport("./modules/emby-apiclient/apiclientex.js")) : define("apiclient", [], getDynamicImport("./modules/emby-apiclient/apiclient.js")), []);
        return self.Emby.requiresClassesPolyfill && responses.push(require(["modules/babelhelpers"])), self.ResizeObserver || responses.push(require(["modules/polyfills/resizeobserver"])), self.IntersectionObserver || responses.push(require(["modules/polyfills/intersection-observer"])), "undefined" == typeof fetch && responses.push(require(["bower_components/fetch/fetch"])), self.tizen && responses.push(require(["$WEBAPIS/webapis/webapis.js"])), Promise.all(responses)
    }

    function start(startInfo) {
        if (localStorage.getItem("enableautobitratebitrate-Video-true") === null) {
            localStorage.setItem("enableautobitratebitrate-Video-true", false);
        }
        if (localStorage.getItem("enableautobitratebitrate-Video-false") === null) {
            localStorage.setItem("enableautobitratebitrate-Video-false", false);
        }
        if (enableNativeGamepadKeyMapping(), self.Windows && self.Windows.UI) {
            try {
                Windows.UI.ViewManagement.ApplicationViewScaling.trySetDisableLayoutScaling(!0)
            } catch (err) {}
            try {
                Windows.UI.ViewManagement.ApplicationView.getForCurrentView().setDesiredBoundsMode(Windows.UI.ViewManagement.ApplicationViewBoundsMode.useCoreWindow)
            } catch (err) {}
        }
        var customPaths, supportsTizenWasmSockets, v, baseRoute, bowerPath;
        return startInfo = startInfo || self.appStartInfo || {}, customPaths = startInfo.paths || {}, bowerPath = "bower_components", define("playMethodHelper", [], getDynamicImport("./modules/common/playback/playmethodhelper.js")), define("itemShortcuts", [], getDynamicImport("./modules/shortcuts.js")), define("pageJs", [], getDynamicImport("./modules/pagejs/page.js")), define("imageoptionseditor", ["components/imageoptionseditor/imageoptionseditor"], returnFirstDependency), define("medialibraryeditor", ["components/medialibraryeditor/medialibraryeditor"], returnFirstDependency), define("medialibrarycreator", ["components/medialibrarycreator/medialibrarycreator"], returnFirstDependency), define("howler", [], getDynamicImport("./modules/howlerjs/howler.core.js")), define("skinManager", [], getDynamicImport("./modules/skinmanager.js")), define("flvjs", [], getDynamicImport("./modules/flvjs/flv.js")), define("playQueueManager", [], getDynamicImport("./modules/common/playback/playqueuemanager.js")), define("focusManager", [], getDynamicImport("./modules/focusmanager.js")), define("browserdeviceprofile", [], getDynamicImport("./modules/browserdeviceprofile.js")), define("inputManager", ["serviceLocator"], getDynamicImport("./modules/common/inputmanager.js")), define("inputmanager", ["inputManager"], returnFirstDependency), define("events", [], getDynamicImport("./modules/emby-apiclient/events.js")), define("credentialprovider", [], getDynamicImport("./modules/emby-apiclient/credentials.js")), define("connectionManager", [], getDynamicImport("./modules/emby-apiclient/connectionmanager.js")), define("loading", [], getDynamicImport("./modules/loading/loading.js")), define("taskButton", [], getDynamicImport("./components/taskbutton.js")), customPaths.fullscreenmanager ? define("fullscreenManager", [customPaths.fullscreenmanager, "serviceLocator"], loadFullscreenManager) : define("fullscreenManager", ["serviceLocator"], loadWebFullscreenManager), customPaths.shell ? define("shell", [addJsExtIfNeeded(customPaths.shell)], returnFirstDependency) : "android" === self.appMode ? define("shell", ["native/android/shell"], returnFirstDependency) : define("shell", [], getDynamicImport("./modules/shell.js")), define("webvtt", [], getDynamicImport("./modules/webvtt/vtt.js")), define("humanedate", [], getDynamicImport("./modules/humanedate/humanedate.js")), define("serviceLocator", [], getDynamicImport("./modules/common/servicelocator.js")), define("globalize", [], getDynamicImport("./modules/common/globalize.js")), define("datetime", [], getDynamicImport("./modules/common/datetime.js")), define("qualityOptions", [], getDynamicImport("./modules/common/qualityoptions.js")), define("pluginManager", [], getDynamicImport("./modules/common/pluginmanager.js")), define("itemHelper", [], getDynamicImport("./modules/common/itemhelper.js")), define("recordingHelper", [], getDynamicImport("./modules/common/recordinghelper.js")), define("deleteHelper", [], getDynamicImport("./modules/common/deletehelper.js")), define("imageLoader", [], getDynamicImport("./modules/imageloader/imageloader.js")), define("backdrop", [], getDynamicImport("./modules/backdrop/backdrop.js")), define("gamepadtokey", [], getDynamicImportWithoutExport("./modules/input/gamepadtokey.js")), define("virtual-scroller", [], getDynamicImport("./modules/virtual-scroller/virtual-scroller.js")), define("commandProcessor", [], getDynamicImport("./modules/commandprocessor.js")), customPaths.filesystem ? define("filesystem", [addJsExtIfNeeded(customPaths.filesystem)], returnFirstDependency) : "android" === self.appMode ? define("filesystem", ["native/android/filesystem"], returnFirstDependency) : define("filesystem", [], getDynamicImport("./modules/common/filesystem.js")), define("cssVars", [bowerPath + "/css-vars-ponyfill/css-vars-ponyfill"], returnFirstDependency), define("hlsjs", ["modules/hlsjs/hls.min"], returnFirstDependency), define("connectionManagerResolver", ["connectionManager"], returnFirstDependency), define("browser", [], getDynamicImport("./modules/browser.js")), define("backMenu", [], getDynamicImport("./modules/backmenu/backmenu.js")), define("soundEffectsManager", [], getDynamicImport("./modules/soundeffects/soundeffectsmanager.js")), define("soundEffectsPlayer", [], getDynamicImport("./modules/soundeffects/soundeffectsplayer.js")), define("mediaSession", [], getDynamicImportWithoutExport("./modules/playback/mediasession.js")), define("libjass", [bowerPath + "/libjass/libjass", "css!" + bowerPath + "/libjass/libjass"], returnFirstDependency), define("SubtitlesOctopus", [bowerPath + "/javascriptsubtitlesoctopus/dist/subtitles-octopus"], returnFirstDependency), define("tunerPicker", ["components/tunerpicker"], returnFirstDependency), define("mainTabsManager", [], getDynamicImport("./modules/maintabsmanager.js")), define("dragDropTouch", [], getDynamicImportWithoutExport("./modules/polyfills/dragdroptouch.js")), define("appHeader", [], getDynamicImport("./modules/appheader/appheader.js")), define("chromecastHelper", [], getDynamicImport("./modules/chromecast/chromecasthelpers.js")), define("directorybrowser", ["components/directorybrowser/directorybrowser"], returnFirstDependency), define("metadataEditor", [], getDynamicImport("./modules/metadataeditor/metadataeditor.js")), define("personEditor", [], getDynamicImport("./modules/metadataeditor/personeditor.js")), define("playerSelectionMenu", [], getDynamicImport("./modules/playback/playerselection.js")), define("playerSettingsMenu", [], getDynamicImport("./modules/playback/playersettingsmenu.js")), define("emby-collapse", [], getDynamicImport("./modules/emby-elements/emby-collapse/emby-collapse.js")), define("emby-button", [], getDynamicImport("./modules/emby-elements/emby-button/emby-button.js")), define("emby-linkbutton", ["emby-button"], returnFirstDependency), define("emby-itemscontainer", [], getDynamicImport("./modules/emby-elements/emby-itemscontainer/emby-itemscontainer.js")), define("alphaNumericShortcuts", [], getDynamicImport("./modules/alphanumericshortcuts/alphanumericshortcuts.js")), define("emby-scroller", [], getDynamicImport("./modules/emby-elements/emby-scroller/emby-scroller.js")), define("emby-tabs", [], getDynamicImport("./modules/emby-elements/emby-tabs/emby-tabs.js")), define("emby-scrollbuttons", [], getDynamicImport("./modules/emby-elements/emby-scrollbuttons/emby-scrollbuttons.js")), define("emby-progressring", [], getDynamicImport("./modules/emby-elements/emby-progressring/emby-progressring.js")), define("emby-itemrefreshindicator", [], getDynamicImport("./modules/emby-elements/emby-itemrefreshindicator/emby-itemrefreshindicator.js")), define("multiSelect", [], getDynamicImport("./modules/multiselect/multiselect.js")), define("alphaPicker", [], getDynamicImport("./modules/alphapicker/alphapicker.js")), define("paper-icon-button-light", [], getDynamicImport("./modules/emby-elements/emby-button/paper-icon-button-light.js")), define("tabbedView", [], getDynamicImport("./modules/tabbedview/tabbedview.js")), define("foldersTab", [], getDynamicImport("./modules/tabbedview/folderstab.js")), define("seriesTab", [], getDynamicImport("./modules/tabbedview/seriestab.js")), define("videosTab", [], getDynamicImport("./modules/tabbedview/videostab.js")), define("artistsTab", [], getDynamicImport("./modules/tabbedview/artiststab.js")), define("playlistsTab", [], getDynamicImport("./modules/tabbedview/playliststab.js")), define("tagsTab", [], getDynamicImport("./modules/tabbedview/tagstab.js")), define("genresTab", [], getDynamicImport("./modules/tabbedview/genrestab.js")), define("collectionsTab", [], getDynamicImport("./modules/tabbedview/collectionstab.js")), define("itemsTab", [], getDynamicImport("./modules/tabbedview/itemstab.js")), define("baseView", [], getDynamicImport("./modules/viewmanager/baseview.js")), define("baseTab", [], getDynamicImport("./modules/tabbedview/basetab.js")), define("ListPage", [], getDynamicImport("./list/list.js")), define("formHelper", [], getDynamicImport("./modules/formhelper.js")), define("thememediaplayer", [], getDynamicImportWithoutExport("./modules/thememediaplayer.js")), define("connectHelper", [], getDynamicImport("./modules/emby-connect/connecthelper.js")), define("addToList", [], getDynamicImport("./modules/addtolist/addtolist.js")), define("searchFields", [], getDynamicImport("./search/searchfields.js")), define("emby-input", [], getDynamicImport("./modules/emby-elements/emby-input/emby-input.js")), define("emby-select", [], getDynamicImport("./modules/emby-elements/emby-select/emby-select.js")), define("emby-slider", [], getDynamicImport("./modules/emby-elements/emby-slider/emby-slider.js")), define("emby-checkbox", [], getDynamicImport("./modules/emby-elements/emby-checkbox/emby-checkbox.js")), define("emby-progressbar", [], getDynamicImport("./modules/emby-elements/emby-progressbar/emby-progressbar.js")), define("embyProgressBarStyle", ["css!modules/emby-elements/emby-progressbar/emby-progressbar"], returnFirstDependency), define("emby-radio", [], getDynamicImport("./modules/emby-elements/emby-radio/emby-radio.js")), define("emby-toggle", [], getDynamicImport("./modules/emby-elements/emby-toggle/emby-toggle.js")), define("emby-textarea", [], getDynamicImport("./modules/emby-elements/emby-textarea/emby-textarea.js")), define("serverRestartDialog", [], getDynamicImport("./modules/serverrestartdialog/serverrestartdialog.js")), define("channelRecordingCreator", [], getDynamicImport("./modules/recordingcreator/channelrecordingcreator.js")), define("recordingCreator", [], getDynamicImport("./modules/recordingcreator/recordingcreator.js")), define("recordingEditor", [], getDynamicImport("./modules/recordingcreator/recordingeditor.js")), define("seriesRecordingEditor", [], getDynamicImport("./modules/recordingcreator/seriesrecordingeditor.js")), define("recordingFields", [], getDynamicImport("./modules/recordingcreator/recordingfields.js")), define("recordingButton", [], getDynamicImport("./modules/recordingcreator/recordingbutton.js")), define("subtitleEditor", [], getDynamicImport("./modules/subtitleeditor/subtitleeditor.js")), define("itemIdentifier", [], getDynamicImport("./modules/itemidentifier/itemidentifier.js")), define("imageEditor", [], getDynamicImport("./modules/imageeditor/imageeditor.js")), define("imageDownloader", [], getDynamicImport("./modules/imagedownloader/imagedownloader.js")), define("itemContextMenu", [], getDynamicImport("./modules/itemcontextmenu.js")), define("dom", [], getDynamicImport("./modules/dom.js")), define("textEncoding", [], getDynamicImport("./modules/common/textencoding.js")), define("playerStats", [], getDynamicImport("./modules/playerstats/playerstats.js")), define("subtitleOffsetOverlay", [], getDynamicImport("./modules/subtitleoffsetoverlay/subtitleoffsetoverlay.js")), define("upNextDialog", [], getDynamicImport("./modules/upnextdialog/upnextdialog.js")), define("subtitleAppearanceHelper", [], getDynamicImport("./modules/common/subtitleappearancehelper.js")), define("playbackManager", ["fullscreenManager"], getDynamicImport("./modules/common/playback/playbackmanager.js")), define("homeSections", [], getDynamicImport("./modules/homesections/homesections.js")), define("refreshDialog", [], getDynamicImport("./modules/refreshdialog/refreshdialog.js")), define("cardStyle", ["css!modules/cardbuilder/card"], returnFirstDependency), define("cardBuilder", [], getDynamicImport("./modules/cardbuilder/cardbuilder.js")), define("mouseManager", [], getDynamicImport("./modules/input/mouse.js")), define("flexStyles", ["css!modules/flexstyles"], returnFirstDependency), define("tvguide", [], getDynamicImport("./modules/emby-elements/guide/guide.js")), define("programStyles", ["css!modules/emby-elements/guide/programs"], returnFirstDependency), define("guide-settings-dialog", [], getDynamicImport("./modules/emby-elements/guide/guide-settings.js")), define("loadingDialog", [], getDynamicImport("./modules/loadingdialog/loadingdialog.js")), define("syncDialog", [], getDynamicImport("./modules/sync/sync.js")), define("syncJobEditor", [], getDynamicImport("./modules/sync/syncjobeditor.js")), define("syncJobList", [], getDynamicImport("./modules/sync/syncjoblist.js")), define("morphdom", [], getDynamicImport("./modules/morphdom/morphdom.js")), define("viewManager", [], getDynamicImport("./modules/viewmanager/viewmanager.js")), customPaths.apphost ? define("apphost", [addJsExtIfNeeded(customPaths.apphost)], returnFirstDependency) : "ios" === self.appMode ? define("apphost", [], getDynamicImport("./native/ios/apphost.js")) : "android" === self.appMode ? define("apphost", ["native/android/apphost"], returnFirstDependency) : "windows" === self.appMode ? define("apphost", ["native/windows/apphost"], returnFirstDependency) : define("apphost", [], getDynamicImport("./modules/apphost.js")), self.tizen && self.tizen.systeminfo && (v = !(supportsTizenWasmSockets = (v = self.tizen.systeminfo.getCapability("http://tizen.org/feature/platform.version")) && parseFloat(v) >= parseFloat("6.0")) && v && parseFloat(v) >= parseFloat("2.4")), customPaths.serverdiscovery ? define("serverdiscovery", [addJsExtIfNeeded(customPaths.serverdiscovery)], returnFirstDependency) : "windows" === self.appMode || "winjs" === self.appMode ? define("serverdiscovery", ["native/windows/serverdiscovery"], returnFirstDependency) : self.tizen && (v || supportsTizenWasmSockets) ? define("serverdiscovery", ["native/tizen/serverdiscovery"], returnFirstDependency) : "android" === self.appMode ? define("serverdiscovery", ["native/android/serverdiscovery"], returnFirstDependency) : "ios" === self.appMode ? define("serverdiscovery", ["native/ios/serverdiscovery"], returnFirstDependency) : define("serverdiscovery", [], getDynamicImport("./modules/emby-apiclient/serverdiscovery.js")), customPaths.wakeonlan ? define("wakeOnLan", [addJsExtIfNeeded(customPaths.wakeonlan)], returnFirstDependency) : "windows" === self.appMode || "winjs" === self.appMode ? define("wakeOnLan", ["native/windows/wakeonlan"], returnFirstDependency) : self.tizen && (v || supportsTizenWasmSockets) ? define("wakeOnLan", ["native/tizen/wakeonlan"], returnFirstDependency) : "ios" === self.appMode ? define("wakeOnLan", ["native/ios/wakeonlan"], returnFirstDependency) : "android" === self.appMode ? define("wakeOnLan", ["native/android/wakeonlan"], returnFirstDependency) : define("wakeOnLan", [], getDynamicImport("./modules/emby-apiclient/wakeonlan.js")), define("appStorage", [], loadAppStorage), customPaths = {
            urlArgs: self.urlCacheParam,
            renameJsExtension: self.Emby.jsExtension
        }, "android" !== self.appMode && ((baseRoute = (baseRoute = self.location.href.split("?")[0].replace("/index.html", "")).split("#")[0]).lastIndexOf("/") === baseRoute.length - 1 && (baseRoute = baseRoute.substring(0, baseRoute.length - 1)), console.log("Setting require baseUrl to " + baseRoute), customPaths.baseUrl = baseRoute), require.config(customPaths), define("slideshow", [], getDynamicImport("./modules/slideshow/slideshow.js")), define("clearButtonStyle", [], returnFirstDependency), define("emby-downloadbutton", [], getDynamicImport("./modules/emby-elements/sync/emby-downloadbutton.js")), define("categorySyncButton", [], getDynamicImport("./modules/sync/categorysyncbutton.js")), define("listView", [], getDynamicImport("./modules/listview/listview.js")), define("listViewStyle", ["css!modules/listview/listview"], returnFirstDependency), define("layoutStyle", ["css!modules/layout"], returnFirstDependency), define("formDialogStyle", ["css!modules/formdialog"], returnFirstDependency), define("sectionsStyle", ["css!modules/sections"], returnFirstDependency), define("indicators", [], getDynamicImport("./modules/indicators/indicators.js")), define("mediaInfo", [], getDynamicImport("./modules/mediainfo/mediainfo.js")), define("emby-playstatebutton", [], getDynamicImport("./modules/emby-elements/userdatabuttons/emby-playstatebutton.js")), define("emby-ratingbutton", [], getDynamicImport("./modules/emby-elements/userdatabuttons/emby-ratingbutton.js")), define("viewSettings", ["modules/viewsettings/viewsettings"], returnFirstDependency), define("filterMenu", [], getDynamicImport("./modules/filtermenu/filtermenu.js")), define("registrationServices", [], getDynamicImport("./modules/registrationservices/registrationservices.js")), define("serversync", [], getDynamicImport("./modules/sync/serversync.js")), define("multiserversync", [], getDynamicImport("./modules/sync/multiserversync.js")), define("mediasync", ["modules/sync/mediasync"], returnFirstDependency), define("idbcore", [], getDynamicImport("./modules/localdatabase/idbcore.js")), define("scroller", [], getDynamicImport("./modules/scroller/smoothscroller.js")), define("scrollStyles", ["css!modules/scrollstyles"], returnFirstDependency), define("toast", [], getDynamicImport("./modules/toast/toast.js")), define("layoutManager", [], getDynamicImport("./modules/layoutmanager.js")), define("appSettings", ["appStorage"], getDynamicImport("./modules/common/appsettings.js")), define("appsettings", ["appSettings"], returnFirstDependency), define("userSettings", [], getDynamicImport("./modules/common/usersettings/usersettings.js")), define("userSettingsBuilder", [], getDynamicImport("./modules/common/usersettings/usersettingsbuilder.js")), define("material-icons", ["css!modules/fonts/material-icons/style"], returnFirstDependency), define("systemFontsCss", ["css!modules/fonts/fonts"], returnFirstDependency), define("imageUploader", [], getDynamicImport("./modules/imageuploader/imageuploader.js")), define("dockedTabs", [], getDynamicImport("./modules/dockedtabs/dockedtabs.js")), define("navdrawer", [], getDynamicImport("./modules/navdrawer/navdrawer.js")), define("navDrawerContent", [], getDynamicImport("./modules/navdrawer/navdrawercontent.js")), define("queryString", [], getDynamicImport("./modules/querystring/querystring.js")), define("alert", [], getDynamicImport("./modules/common/dialogs/alert.js")), define("confirm", [], getDynamicImport("./modules/common/dialogs/confirm.js")), define("dialog", [], getDynamicImport("./modules/dialog/dialog.js")), define("dialogHelper", [], getDynamicImport("./modules/dialoghelper/dialoghelper.js")), define("dialogTemplateHtml", ["text!modules/dialog/dialog.template.html"], returnFirstDependency), define("prompt", [], getDynamicImport("./modules/prompt/prompt.js")), define("jQuery", [bowerPath + "/jquery/jquery-slim"], function () {
            return self.ApiClient && (self.jQuery.ajax = self.ApiClient.ajax), self.jQuery
        }), define("screensaverManager", [], getDynamicImport("./modules/screensavermanager.js")), define("serverNotifications", [], getDynamicImport("./modules/common/input/api.js")), define("apiInput", ["serverNotifications"], returnFirstDependency), define("headroom", [], getDynamicImport("./modules/headroom/headroom.js")), define("appFooter", [], getDynamicImport("./modules/appfooter/appfooter.js")), define("apiClientResolver", ["connectionManager"], function (connectionManager) {
            return function () {
                return connectionManager.currentApiClient()
            }
        }), define("appRouter", [], getDynamicImport("./modules/approuter.js")), define("embyRouter", ["appRouter"], returnFirstDependency), define("actionsheet", [], getDynamicImport("./modules/actionsheet/actionsheet.js")), define("webActionSheet", ["actionsheet"], returnFirstDependency), self.tizen && v && define("sockets", ["native/tizen/naclSockets/sockets"], returnFirstDependency), self.tizen && supportsTizenWasmSockets && define("sockets", ["native/tizen/wasmSockets/sockets"], returnFirstDependency), "android" === self.appMode ? define("iapManager", ["native/android/iap"], returnFirstDependency) : "ios" === self.appMode ? define("iapManager", ["native/ios/iap"], returnFirstDependency) : define("iapManager", [], getDynamicImport("./modules/iap.js")), define("multi-download", [], getDynamicImport("./modules/multidownload.js")), define("videoosd_infotab", [], getDynamicImport("./videoosd/infotab.js")), define("videoosd_chapterstab", [], getDynamicImport("./videoosd/chapterstab.js")), define("videoosd_peopletab", [], getDynamicImport("./videoosd/peopletab.js")), define("videoosd_onnowtab", [], getDynamicImport("./videoosd/onnowtab.js")), define("videoosd_guidetab", [], getDynamicImport("./videoosd/guidetab.js")), define("localassetmanager", ["modules/localdatabase/localassetmanager"], returnFirstDependency), "ios" === self.appMode ? define("cameraUpload", ["native/ios/cameraupload"], returnFirstDependency) : "android" === self.appMode && define("cameraUpload", ["native/android/cameraupload"], returnFirstDependency), define("detailtablecss", ["css!css/detailtable.css"], returnFirstDependency), Promise.all([importFromPath("./modules/browser.js")]).then(loadFirstLevelPolyfills).then(loadSecondLevelPolyfills, loadSecondLevelPolyfills).then(loadThirdLevelPolyfills, loadThirdLevelPolyfills).then(loadServiceLocator).then(createConnectionManager).then(loadGlobalization).then(loadFirstLevelPresentationDependencies).then(function () {
            console.log("loadPlugins");
            var startInfo = this;
            return Promise.all([importFromPath("./modules/common/servicelocator.js"), importFromPath("./modules/browser.js"), importFromPath("./modules/approuter.js")]).then(function (responses) {
                var appHost = responses[0].appHost,
                    responses = responses[1],
                    externalPlugins = (appHost.supports("windowstate") && (document.querySelector(".skinHeader").insertAdjacentHTML("beforeend", '<div class="windowDragRegion hide-mouse-idle-tv"></div>'), require(["css!modules/windowdrag.css"])), startInfo.plugins || []),
                    list = (console.log("Loading installed plugins"), ["./modules/common/playback/playbackvalidation.js", "./modules/common/playback/playaccessvalidation.js", "./modules/common/playback/experimentalwarnings.js"]);
                appHost.supports("soundeffects") && list.push("modules/soundeffects/defaultsoundeffects/plugin"), appHost.supports("screensaver") && (list.push("./modules/logoscreensaver/plugin.js"), list.push("./modules/backdropscreensaver/plugin.js"), list.push("./modules/photoscreensaver/plugin.js")), "android" === self.appMode ? (list.push("native/android/mpvvideoplayer"), list.push("native/android/mpvaudioplayer")) : "ios" === self.appMode ? (list.push("./native/ios/mpvaudioplayer.js"), list.push("./native/ios/mpvvideoplayer.js")) : "windows" === self.appMode && (list.push("native/windows/mpvvideoplayer"), list.push("native/windows/nativeaudioplayer")), list.push("./modules/htmlaudioplayer/plugin.js"), "ios" === self.appMode && list.push("native/ios/chromecast"), "android" === self.appMode && (list.push("native/android/externalplayer"), list.push("native/android/chromecast")), self.webapis && webapis.avplay ? list.push("native/tizen/tizenavplayer/plugin") : list.push("./modules/htmlvideoplayer/plugin.js"), list.push("./modules/photoplayer/plugin.js"), appHost.supports("remotecontrol") && (list.push("./modules/sessionplayer.js"), !self.chrome || responses.edge || responses.electron || "android" === self.appMode || list.push("./modules/chromecast/chromecastplayer.js")), (appHost.supports("youtube") || responses.electron) && ("winjs" === self.appMode ? list.push("native/windows/youtubeplayer/plugin") : list.push("./modules/youtubeplayer/plugin.js"));
                for (var i = 0, length = externalPlugins.length; i < length; i++) list.push(externalPlugins[i]);
                return responses.electron && list.push("modules/externalplayer/plugin"), list.push("./modules/confirmstillplaying/plugin.js"), Promise.all(list.map(loadPlugin))
            })
        }.bind(startInfo)).then(function () {
            return console.log("loadExternalScripts"), require(this.scripts || [])
        }.bind(startInfo)).then(loadHeader).then(onAppReady)
    }
    self.Emby || (self.Emby = {}), self.Emby.importModule = importFromPath, self.Emby.App = {
        start: start
    }, -1 === self.location.href.toString().toLowerCase().indexOf("autostart=false") && start()
}();