define(["exports", "./globalize.js"], function (_exports, _globalize) {
    function getDisplayRunningTime(ticks) {
        var parts = [],
            hours = ticks / 36e9,
            minutes = ((hours = Math.floor(hours)) && parts.push(hours), (ticks -= 36e9 * hours) / 6e8),
            hours = (ticks -= 6e8 * (minutes = Math.floor(minutes)), parts.push(minutes = minutes < 10 && hours ? "0" + minutes : minutes), ticks / 1e7),
            hours = Math.floor(hours);
        return parts.push(hours = hours < 10 ? "0" + hours : hours), parts.join(":")
    }
    Object.defineProperty(_exports, "__esModule", {
        value: !0
    }), _exports.default = void 0;
    var toLocaleTimeStringSupportsLocales = function () {
        try {
            (new Date).toLocaleTimeString("i")
        } catch (e) {
            return "RangeError" === e.name
        }
        return !1
    }();

    function toLocaleTimeString(date, options) {
        if (!date) throw new Error("date cannot be null");
        if (options = options || {}, toLocaleTimeStringSupportsLocales) {
            var currentLocale = _globalize.default.getCurrentDateTimeLocale();
            if (currentLocale) return date.toLocaleTimeString(currentLocale, options)
        }
        return date.toLocaleTimeString()
    }
    _exports.default = {
        parseISO8601Date: function (s) {
            return new Date(Date.parse(s))
        },
        getDisplayRunningTime: getDisplayRunningTime,
        toLocaleDateString: function (date, options) {
            if (!date) throw new Error("date cannot be null");
            if (options = options || {}, toLocaleTimeStringSupportsLocales) {
                var currentLocale = _globalize.default.getCurrentDateTimeLocale();
                if (currentLocale) return date.toLocaleDateString(currentLocale, options)
            }
            return 1 === (currentLocale = function (options) {
                var i, list = [];
                for (i in options) list.push({
                    name: i,
                    value: options[i]
                });
                return list
            }(options)).length && "weekday" === currentLocale[0].name ? (options = [], "long" === currentLocale[0].value ? (options[0] = "Sunday", options[1] = "Monday", options[2] = "Tuesday", options[3] = "Wednesday", options[4] = "Thursday", options[5] = "Friday", options[6] = "Saturday") : (options[0] = "Sun", options[1] = "Mon", options[2] = "Tue", options[3] = "Wed", options[4] = "Thu", options[5] = "Fri", options[6] = "Sat"), options[date.getDay()]) : date.toLocaleDateString()
        },
        toLocaleString: function (date, options) {
            if (!date) throw new Error("date cannot be null");
            if (options = options || {}, toLocaleTimeStringSupportsLocales) {
                var currentLocale = _globalize.default.getCurrentDateTimeLocale();
                if (currentLocale) return date.toLocaleString(currentLocale, options)
            }
            return date.toLocaleString()
        },
        getDisplayTime: function (date) {
            if (!date) throw new Error("date cannot be null");
            if ("string" === (typeof date).toString().toLowerCase()) try {
                date = new Date(Date.parse(date))
            } catch (err) {
                return date
            }
            if (toLocaleTimeStringSupportsLocales) return toLocaleTimeString(date, {
                hour: "numeric",
                minute: "2-digit"
            });
            var suffix, time = toLocaleTimeString(date),
                timeLower = time.toLowerCase();
            return timeLower.includes("am") || timeLower.includes("pm") ? (time = timeLower, timeLower = date.getHours() % 12, suffix = 11 < date.getHours() ? "pm" : "am", time = (timeLower = timeLower || 12) + (timeLower = ":" + (timeLower = (timeLower = date.getMinutes()) < 10 ? "0" + timeLower : timeLower)) + suffix) : 2 < (date = time.split(":")).length && (date.length = 2, time = date.join(":")), time
        },
        isRelativeDay: function (date, offsetInDays) {
            if (!date) throw new Error("date cannot be null");
            var yesterday = new Date,
                offsetInDays = yesterday.getDate() + offsetInDays;
            return yesterday.setDate(offsetInDays), date.getFullYear() === yesterday.getFullYear() && date.getMonth() === yesterday.getMonth() && date.getDate() === offsetInDays
        },
        toLocaleTimeString: toLocaleTimeString,
        supportsLocalization: function () {
            return toLocaleTimeStringSupportsLocales
        },
        getHumanReadableRuntime: function (ticks) {
            try {
                var days = Math.trunc(ticks / 864e9),
                    hours = Math.trunc(ticks % 864e9 / 36e9),
                    mins = Math.trunc(ticks % 36e9 / 6e8),
                    parts = [];
                return days && parts.push(days + "天"), hours && parts.push(hours + "小时"), mins && parts.push(mins + "分钟"), parts.length ? parts.join("") : getDisplayRunningTime(ticks)
            } catch (err) {
                return getDisplayRunningTime(ticks)
            }
        }
    }
});